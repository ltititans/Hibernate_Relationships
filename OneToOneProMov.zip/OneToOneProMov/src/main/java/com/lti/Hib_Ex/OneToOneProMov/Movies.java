package com.lti.Hib_Ex.OneToOneProMov;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Movies")
public class Movies {
	@Id
    @Column(name = "Movies_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_EA")
	@SequenceGenerator(name="my_entity_seq_gen_EA", sequenceName="Movies_seq",allocationSize=1)
	
    private int Movies_id;
    
    @Column(name="name")
    private String name;
    
    
    @Column(name="orderdate")
	@Temporal(TemporalType.DATE)
    private Date releasedate;
    
    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "Producers_id")
    private Producers producers;

    

    public Movies() {
		super();
	}


   

	public Movies(String name, Date releasedate, Producers producers) {
		super();
		this.name = name;
		this.releasedate = releasedate;
		this.producers = producers;
	}




	public int getMovies_id() {
		return Movies_id;
	}


	public void setMovies_id(int movies_id) {
		Movies_id = movies_id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Producers getProducers() {
		return producers;
	}


	public void setProducers(Producers producers) {
		this.producers = producers;
	}


	public Date getReleasedate() {
		return releasedate;
	}




	public void setReleasedate(Date releasedate) {
		this.releasedate = releasedate;
	}




	@Override
	public String toString() {
		return "Movies [Movies_id=" + Movies_id + ", name=" + name + ", releasedate=" + releasedate + ", producers="
				+ producers + "]";
	}





}

