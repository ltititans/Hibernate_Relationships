package com.lti.Hib_Ex.OneToOneProMov;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.Hib_Ex.OneToOneProMov.Producers;
import com.lti.Hib_Ex.OneToOneProMov.Movies;

public class App 
{
    public static void main( String[] args ) throws ParseException
    {
    	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("Persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);
		
		
		Movies m=new Movies();
		Producers p=new Producers();

		System.out.println("Enter Movie Name");
		String name = sc.next();
		 m.setName(name);
		 
		 Date releasedate;
	        
	        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");  
	        System.out.println("Enter date");
	        String date=sc.next();
	        releasedate=dateFormat.parse(date);
	        m.setReleasedate(releasedate);
	        entityManager.persist(p);
		       m.setProducers(p);

		
		
		System.out.println("Enter producer name");
		String name2 = sc.next();
		p.setName(name2);
		
		System.out.println("Enter production name");
		String pname = sc.next();
		p.setPname(pname);
		entityManager.persist(m);
		p.setMovies(m);
		
		
	       System.out.println("Saving to Database");
	       entityManager.persist(p);
//	        System.out.println("Enter name");
//	        String name=ob.next();
//	        p.setName(name);
//	        System.out.println("Enter price");
//	        int price=ob.nextInt();
//	        p.setPrice(price);
//	        Order1 or=new Order1();
//	        Date orderdate;
//	        
//	        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");  
//	        System.out.println("Enter date");
//	        String date=ob.next();
//	       orderdate=dateFormat.parse(date);
//	       or.setOrderdate(orderdate);
//	        entityManager.persist(p);
//	        or.setProduct(p);
	        
//	        System.out.println("Saving Book to Database");
//	        entityManager.persist(or);
	        
	        entityManager.getTransaction().commit();
	        System.out.println("Generated Producer ID = " + p.getProducers_id());
	        System.out.println("Generated Movie ID = " + m.getMovies_id());



		
    }
}
