package com.lti.collegeMainclass;

public class CollegeMainClass {

}
