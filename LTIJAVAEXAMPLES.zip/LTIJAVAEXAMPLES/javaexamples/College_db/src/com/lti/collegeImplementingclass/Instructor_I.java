package com.lti.collegeImplementingclass;

import com.lti.collegeinterface.InstructorInterface;

public class Instructor_I implements InstructorInterface {

	@Override
	public void addInstructor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayInstructor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInstructor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateInstructor() {
		// TODO Auto-generated method stub
		
	}

}
