package com.lti.collegeImplementingclass;

import com.lti.collegeinterface.DepartmentInterface;

public class Department_I implements DepartmentInterface{

	@Override
	public void addDept() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayDept() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDept() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDept() {
		// TODO Auto-generated method stub
		
	}

}
