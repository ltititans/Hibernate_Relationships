package com.lti.collegeImplementingclass;

import com.lti.collegeinterface.StudentInterface;

public class Course_I implements StudentInterface {

	@Override
	public void addStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteStud() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateStud() {
		// TODO Auto-generated method stub
		
	}

}
