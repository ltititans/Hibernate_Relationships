package com.lti.collegeinterface;

public interface DepartmentInterface {
	void addDept();
	void displayDept();
	void deleteDept();
	void updateDept();
}
