package com.lti.collegeinterface;

public interface InstructorInterface {
	void addInstructor();
	void displayInstructor();
	void deleteInstructor();
	void updateInstructor();
}
