package com.lti.collegeinterface;

public interface StudentInterface {

	void addStud();
	void displayStud();
	void deleteStud();
	void updateStud();
}
