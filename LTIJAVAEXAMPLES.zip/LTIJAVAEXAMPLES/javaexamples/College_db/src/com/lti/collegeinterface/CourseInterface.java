package com.lti.collegeinterface;

public interface CourseInterface {
	
		
		void addCourse();
		void displayCourse();
		void deleteCourse();
		void updateCourse();
		

}
