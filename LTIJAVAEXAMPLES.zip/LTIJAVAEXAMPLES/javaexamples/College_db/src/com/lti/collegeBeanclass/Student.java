package com.lti.collegeBeanclass;

public class Student {

	
	private int sno;
	private String sname;
	private String dob;
	
	private Course cb;
	private Instructor ib;
	public Student(int sno, String sname, String dob, Course cb, Instructor ib) {
		this.sno = sno;
		this.sname = sname;
		this.dob = dob;
		this.cb = cb;
		this.ib = ib;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public Course getCb() {
		return cb;
	}
	public void setCb(Course cb) {
		this.cb = cb;
	}
	public Instructor getIb2() {
		return ib;
	}
	public void setIb2(Instructor ib) {
		this.ib = ib;
	}
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", sname=" + sname + ", dob=" + dob + ", cb=" + cb + ", ib=" + ib + "]";
	}
	
}
