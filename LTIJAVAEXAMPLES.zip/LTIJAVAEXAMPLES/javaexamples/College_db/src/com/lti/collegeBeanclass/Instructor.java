package com.lti.collegeBeanclass;

public class Instructor {

	private int iid;
	private String iname;
	private String room;
	private Department db;
	public Instructor(int iid, String iname, String room, Department db) {
		this.iid = iid;
		this.iname = iname;
		this.room = room;
		this.db = db;
	}
	public int getIid() {
		return iid;
	}
	public void setIid(int iid) {
		this.iid = iid;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public Department getDb() {
		return db;
	}
	public void setDb(Department db) {
		this.db = db;
	}
	@Override
	public String toString() {
		return "Instructor [iid=" + iid + ", iname=" + iname + ", room=" + room + ", db=" + db + "]";
	}
}
