import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
public class TestArrayIntList {
      @Test
      public class testAddGet1(){
    	  
    	  List<Integer> list = new ArrayList<>();
    	  list.add(42);
    	  list.add(-3);
    	  list.add(23);
    	  assertEquals(42, list.get(0));
    	  assertEquals(56, list.get(0));
    	  assertEquals(23, list.get(0));
    	  
      }
      
}
