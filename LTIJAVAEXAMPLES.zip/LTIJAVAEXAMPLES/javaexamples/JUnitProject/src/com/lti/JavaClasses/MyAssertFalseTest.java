package com.lti.JavaClasses;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyAssertFalseTest {

	@Test
	public void test() {
		EvenNumber e= new EvenNumber();
		
	}

}
