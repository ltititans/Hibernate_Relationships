package com.lti.JUnitCases;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClassTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
