package com.lti.collegedetails.beanclasses;

public class dept {
      private int depno;
      private String depname;
      private String loc;
	public dept(int depno, String depname, String loc) {
		this.depno = depno;
		this.depname = depname;
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "dept [depno=" + depno + ", depname=" + depname + ", loc=" + loc + "]";
	}
	public int getDepno() {
		return depno;
	}
	public void setDepno(int depno) {
		this.depno = depno;
	}
	public String getDepname() {
		return depname;
	}
	public void setDepname(String depname) {
		this.depname = depname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
}
