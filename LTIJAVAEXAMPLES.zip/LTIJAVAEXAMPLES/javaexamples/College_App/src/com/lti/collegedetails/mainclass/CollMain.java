package com.lti.collegedetails.mainclass;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.lti.collegedetails.beanclasses.dept;
import com.lti.collegedetails.beanclasses.inst;

public class CollMain {


	public void add_deptinfo()
	{
		
		List<dept> li = new ArrayList<dept>();
		li .add(new dept(1,"HR","Chennai"));
		li.add(new dept(2,"Admin","Madras"));
		li.add(new dept(3,"HR","Mumbai"));
			
	}
//	dept d =new dept(li);
	public void add_instinfo()
	{
		List<inst> li=new ArrayList<inst>();
		li.add(new inst(1,"Rashmi", 974013, 16, new dept(1,"HR","Chennai") ));
//		li.add(new inst());
//		li.add(new inst());
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
          System.out.println("enter n \n");
          Scanner in= new Scanner(System.in);
          n=in.nextInt();
          dept d[]=new dept[n];
          inst i1[]=new inst[n];
         
          
          
	}

}
