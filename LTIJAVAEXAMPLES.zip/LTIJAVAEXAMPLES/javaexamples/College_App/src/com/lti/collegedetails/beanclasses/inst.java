package com.lti.collegedetails.beanclasses;

public class inst {
    
	private int i_id;
	private String i_name;
	private int  telph;
	private int room_no;
	private dept d;
	public inst(int i_id, String i_name, int telph, int room_no, dept d) {
		this.i_id = i_id;
		this.i_name = i_name;
		this.telph = telph;
		this.room_no = room_no;
		this.d = d;
	}
	public int getI_id() {
		return i_id;
	}
	public void setI_id(int i_id) {
		this.i_id = i_id;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public int getTelph() {
		return telph;
	}
	public void setTelph(int telph) {
		this.telph = telph;
	}
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public dept getD() {
		return d;
	}
	public void setD(dept d) {
		this.d = d;
	}
	@Override
	public String toString() {
		return "inst [i_id=" + i_id + ", i_name=" + i_name + ", telph=" + telph + ", room_no=" + room_no + ", d=" + d
				+ "]";
	}
	
	

}
