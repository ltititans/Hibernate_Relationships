package com.lti.bankdetails.MainClass;

import com.lti.bankdetails.beanclasses.BankAccBean;
import com.lti.bankdetails.beanclasses.CustomerBean;

public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                CustomerBean cb=new CustomerBean("Sudeepth","P","sudeepth.rao@gmail.com","8139963645");
                BankAccBean bb=new BankAccBean("SCB11", cb, 25000.0);
                System.out.println(bb);
	}

}
