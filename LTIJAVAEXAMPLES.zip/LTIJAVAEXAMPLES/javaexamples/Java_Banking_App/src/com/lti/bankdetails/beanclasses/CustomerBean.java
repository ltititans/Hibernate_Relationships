package com.lti.bankdetails.beanclasses;

public class CustomerBean {
	private String fname;
	private String lname;
	private String email;
	private String phno;
	public CustomerBean(String fname, String lname, String email, String phno) {
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.phno = phno;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "CustomerBean [fname=" + fname + ", lname=" + lname + ", email=" + email + ", phno=" + phno + "]";
	}

}
