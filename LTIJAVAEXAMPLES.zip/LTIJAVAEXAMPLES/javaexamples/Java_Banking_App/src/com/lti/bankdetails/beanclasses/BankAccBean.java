package com.lti.bankdetails.beanclasses;

public class BankAccBean {
	private String accNo;
	private CustomerBean owner;
	private double balance;
	public BankAccBean(String accNo, CustomerBean owner, double balance) {
		this.accNo = accNo;
		this.owner = owner;
		this.balance = balance;
	}
	public String getAccNo() {
		return accNo;
	}
	@Override
	public String toString() {
		return "BankAccBean [accNo=" + accNo + ", owner=" + owner + ", balance=" + balance + "]";
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public CustomerBean getOwner() {
		return owner;
	}
	public void setOwner(CustomerBean owner) {
		this.owner = owner;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

}
