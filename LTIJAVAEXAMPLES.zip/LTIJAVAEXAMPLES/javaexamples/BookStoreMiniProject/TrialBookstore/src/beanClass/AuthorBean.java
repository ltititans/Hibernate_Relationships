package beanClass;

public class AuthorBean {
private int aid;
private String aname;
}
