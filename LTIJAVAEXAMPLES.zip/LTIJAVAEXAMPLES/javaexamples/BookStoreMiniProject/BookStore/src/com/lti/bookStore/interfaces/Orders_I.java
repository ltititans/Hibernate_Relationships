package com.lti.bookStore.interfaces;

public interface Orders_I {
	void addO();
	   void updateO();
	   void displayO();
	   void deleteO();
}
