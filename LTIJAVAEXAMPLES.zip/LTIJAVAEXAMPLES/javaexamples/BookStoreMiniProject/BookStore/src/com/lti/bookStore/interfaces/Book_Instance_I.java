package com.lti.bookStore.interfaces;

import java.sql.SQLException;

public interface Book_Instance_I {
	   void addBI() throws Exception;
	   void updateBI() throws Exception;
	   void displayBI() throws Exception;
	   void deleteBI() throws Exception;
}
