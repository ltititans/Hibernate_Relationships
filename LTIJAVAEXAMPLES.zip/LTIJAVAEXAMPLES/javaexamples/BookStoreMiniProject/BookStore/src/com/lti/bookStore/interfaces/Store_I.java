package com.lti.bookStore.interfaces;

public interface Store_I {
	void addS();
	   void updateS();
	   void displayS();
	   void deleteS();
}
