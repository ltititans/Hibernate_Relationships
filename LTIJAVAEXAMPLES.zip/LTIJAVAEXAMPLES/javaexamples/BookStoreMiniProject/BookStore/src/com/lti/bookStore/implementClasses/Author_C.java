package com.lti.bookStore.implementClasses;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.lti.bookStore.Jdbc.Jdbc_Connect;
import com.lti.bookStore.beanClasses.Author;
import com.lti.bookStore.interfaces.Author_I;

public class Author_C implements Author_I {
	Author a = new Author();

	int author_id;
	String first_name,last_name,email_address;
	int choice=0;

	// Author a[]=new Author[10];

	//    Scanner sc=new Scanner(System.in);
	//   Author_C c=new Author_C();

	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	@Override
	public void addA() throws SQLException,  IOException, ClassNotFoundException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();			  
		PreparedStatement ps = con.prepareStatement("insert into author values(?,?,?,?)");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		do{
			System.out.println("Enter author_id");
			a.setAuthor_id(Integer.parseInt(br.readLine()));

			System.out.println("Enter first_name");
			String f_name = br.readLine();

			System.out.println("Enter last name");
			String l_name = br.readLine();

			System.out.println("Enter email address");
			String email = br.readLine();

			ps.setInt(1, a.getAuthor_id());
			ps.setString(2, f_name);
			ps.setString(3, l_name);
			ps.setString(4, email);

			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );

			System.out.println("do you want to continue: y/n");
			String s = br.readLine();
			if(s.startsWith("n")){
				break;
			}

		}while(true);
		con.close();


	}

	@Override
	public void updateA() throws SQLException, NumberFormatException, IOException {


		con=Jdbc_Connect.getConnect();
		st=con.createStatement();


		PreparedStatement ps = con.prepareStatement("update author set first_name= ? where author_id = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));



		System.out.println("Enter author_id");
		int id = Integer.parseInt(br.readLine());

		System.out.println("Enter first_name");
		String f_name = br.readLine();
		ps.setInt(2, id);
		ps.setString(1, f_name);


		int i = ps.executeUpdate();
		System.out.println(i+ "records affected " );

	}


	@Override
	public void displayA() throws SQLException, NumberFormatException, IOException {
		//		

		con=Jdbc_Connect.getConnect();
		st=con.createStatement();
		Scanner sc = new Scanner(System.in);

		System.out.println("1.View all");
		System.out.println("2.View One");
		System.out.println("Enter your choice");

		choice = sc.nextInt();


		switch(choice)	


		{
		
		case 1:	 
			String q="Select * from author";

			//to execute query
			ResultSet rs=st.executeQuery(q);
			

			//to print the resultset on console
			if(rs.next()){ 
				do{
					System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getString(3)+" " + rs.getString(4));

				}while(rs.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
			con.close();
			break;
		case 2:
			PreparedStatement ps1 = con.prepareStatement("select * from author where author_id = ?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("Enter author_id");
			int id = Integer.parseInt(br.readLine());
			ps1.setInt(1, id);
			rs = ps1.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getString(3)+" " + rs.getString(4));
			}
			break;
		}
	}





}
