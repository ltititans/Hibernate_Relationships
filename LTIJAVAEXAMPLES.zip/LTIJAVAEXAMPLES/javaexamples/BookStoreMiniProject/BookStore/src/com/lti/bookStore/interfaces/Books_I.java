package com.lti.bookStore.interfaces;

public interface Books_I {
	void addB() throws Exception;
	   void updateB() throws Exception;
	   void displayB() throws Exception;
	   void deleteB() throws Exception;
}
