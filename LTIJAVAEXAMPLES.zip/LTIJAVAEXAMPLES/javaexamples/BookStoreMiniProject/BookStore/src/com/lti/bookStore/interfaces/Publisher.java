package com.lti.bookStore.interfaces;

public interface Publisher {
	void addP();
	   void updateP();
	   void displayP();
	   void deleteP();
}
