package com.lti.bookStore.beanClasses;

public class Publisher {
   private String publisher_code;
   private int publisher_id;
   private String publisher_name;
   private String email_address;
   private String website;
public Publisher(String publisher_code, int publisher_id, String publisher_name, String email_address, String website) {
	super();
	this.publisher_code = publisher_code;
	this.publisher_id = publisher_id;
	this.publisher_name = publisher_name;
	this.email_address = email_address;
	this.website = website;
}
public String getPublisher_code() {
	return publisher_code;
}
public void setPublisher_code(String publisher_code) {
	this.publisher_code = publisher_code;
}
public int getpublisher_id() {
	return publisher_id;
}
public void setpublisher_id(int publisher_id) {
	this.publisher_id = publisher_id;
}
public String getPublisher_name() {
	return publisher_name;
}
public void setPublisher_name(String publisher_name) {
	this.publisher_name = publisher_name;
}
public String getEmail_address() {
	return email_address;
}
public void setEmail_address(String email_address) {
	this.email_address = email_address;
}
public String getWebsite() {
	return website;
}
public void setWebsite(String website) {
	this.website = website;
}
@Override
public String toString() {
	return "Publisher [publisher_code=" + publisher_code + ", publisher_id=" + publisher_id + ", publisher_name="
			+ publisher_name + ", email_address=" + email_address + ", website=" + website + "]";
}
   
}
