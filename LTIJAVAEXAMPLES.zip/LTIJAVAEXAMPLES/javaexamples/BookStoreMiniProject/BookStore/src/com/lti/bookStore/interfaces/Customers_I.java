package com.lti.bookStore.interfaces;

public interface Customers_I {
	void addCI() throws Exception;
	   void updateCI() throws Exception;
	   void displayCI() throws Exception;
	   void deleteCI() throws Exception;
}
