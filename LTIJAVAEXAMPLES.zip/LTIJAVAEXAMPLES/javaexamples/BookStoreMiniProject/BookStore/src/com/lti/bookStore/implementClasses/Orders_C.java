package com.lti.bookStore.implementClasses;

import com.lti.bookStore.interfaces.Orders_I;

public class Orders_C implements Orders_I{

	@Override
	public void addO() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateO() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayO() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteO() {
		// TODO Auto-generated method stub
		
	}

}
