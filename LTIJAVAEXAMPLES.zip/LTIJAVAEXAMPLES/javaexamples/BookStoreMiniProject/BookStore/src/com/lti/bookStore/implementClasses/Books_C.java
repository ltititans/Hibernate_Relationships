package com.lti.bookStore.implementClasses;

import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.lti.bookStore.Jdbc.Jdbc_Connect;
import com.lti.bookStore.beanClasses.Author;
import com.lti.bookStore.beanClasses.Books;
import com.lti.bookStore.beanClasses.Publisher;
import com.lti.bookStore.interfaces.Books_I;

public class Books_C implements Books_I{

	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	int choice=0;

	@Override
	public void addB() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();			  
		PreparedStatement ps = con.prepareStatement("insert into author values(?,?,?,?)");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		do{
			System.out.println("Enter ISBN");
			int isbn = Integer.parseInt(br.readLine());

			System.out.println("Enter Book title");
			String b_title = br.readLine();

			System.out.println("Enter Author id");
			int a_id = Integer.parseInt(br.readLine());

			System.out.println("Enter Publisher id");
			int p_id = Integer.parseInt(br.readLine());

			ps.setInt(1, isbn);
			ps.setString(2,b_title);
			ps.setInt(3, a_id);
			ps.setInt(4, p_id);

			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );

			System.out.println("do you want to continue: y/n");
			String s = br.readLine();
			if(s.startsWith("n")){
				break;
			}

		}while(true);
		con.close();

	}

	@Override
	public void updateB() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();


		PreparedStatement ps = con.prepareStatement("update book title a_id= ? where isbn = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));



		System.out.println("Enter Book title");
	String title=br.readLine();

		System.out.println("Enter isbn");
		int isbn = Integer.parseInt(br.readLine());
		ps.setInt(2, isbn);
		ps.setString(1, title);


		int i = ps.executeUpdate();
		System.out.println(i+ "records affected " );

	}

	@Override
	public void displayB() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();

		Scanner sc = new Scanner(System.in);

		st=con.createStatement();
		System.out.println("Enter your choice");

		int  choice = sc.nextInt();

		System.out.println("1.View all");
		System.out.println("2.View One");

		switch(choice)	


		{
		case 1:	 
			String q="Select * from Books";

			//to execute query
			ResultSet rs=st.executeQuery(q);

			//to print the resultset on console
			if(rs.next()){ 
				do{
					System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getInt(3)+" " + rs.getInt(4));

				}while(rs.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
		
			break;
		case 2:
			PreparedStatement ps1 = con.prepareStatement("select * from Books where isbn = ?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("Enter isbn");
			int isbn = Integer.parseInt(br.readLine());
			rs = ps1.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getInt(3)+" " + rs.getInt(4));
			}
			break;
		}

	}

	@Override
	public void deleteB() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();


		PreparedStatement ps = con.prepareStatement("delete from Books where isbn = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));




		System.out.println("Enter ISBN");
		int isbn = Integer.parseInt(br.readLine());

		ps.setInt(1, isbn);


		int i = ps.executeUpdate();
		System.out.println(i+ "records affected " );
	}

}


