package com.lti.bookStore.ExceptionClass;

public class MyExceptions extends Exception{

	public String   ID_Integrity()
	{
	   return"My Exception object :ID Cannot be ALPHANUMERIC";
	   
	}
	public String   ISBN_Integrity()
	{
	   return"My Exception object :ISBN should have 14 digits";
	   
	}    
}
