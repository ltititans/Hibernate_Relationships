package com.lti.bookStore.interfaces;

public interface Order_Details_I {
	void addOD() throws Exception;
	   void updateOD() throws Exception;
	   void displayOD() throws Exception;
	   void deleteOD() throws Exception;
}
