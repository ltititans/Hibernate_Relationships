package com.lti.bookStore.MainClass;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.lti.bookStore.beanClasses.Author;
import com.lti.bookStore.beanClasses.Books;
import com.lti.bookStore.implementClasses.Author_C;
import com.lti.bookStore.implementClasses.Book_instance_C;
import com.lti.bookStore.implementClasses.Books_C;

public class BooksMainClass {

	public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {

		int choice=0,count;

		Author_C a=new Author_C();
		Book_instance_C  bi=new Book_instance_C ();
		Books_C b = new Books_C();


		Scanner sc=new Scanner(System.in);
		while(true){

			System.out.println("Welcome to bookstore");
			System.out.println("1.Author");
			System.out.println("2.Book Instance ");
			System.out.println("3.Books");
			System.out.println("4.Customers");
			System.out.println("5.Order details");
			System.out.println("6.Publisher");
			System.out.println("7.Stores");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice){
			case 1:

				System.out.println("Add author details");
				System.out.println("1.Add details");
				System.out.println("2.Display details");
				System.out.println("3.Update details");

				System.out.println("Enter your choice");
				choice=sc.nextInt();

				if(choice==1){
					a.addA();
				}
				////			if(choice==2){
				////				System.out.println("Updating Author details");
				////				System.out.println("Enter id to update");
				////				author_id=sc.nextInt();
				////				for(int i=0;i<count;i++){
				////					if(a[i]!=null && a[i].getAuthor_id()==author_id){
				////						System.out.println("Enter Author first name");
				////						first_name=sc.next();
				////						a[i].setFirst_name(first_name);
				////						System.out.println("Enter Author last name");
				////						last_name=sc.next();
				////						a[i].setLast_name(last_name);
				////						System.out.println("Enter Author email address");
				////						email_address=sc.next();
				////						a[i].setEmail_address(email_address);
				////					}
				////					System.out.println("Updated successfully");
				////				}
				////				if(choice==3){
				////					System.out.println("view Author details");
				////					
				////					for(int i=0;i<count;i++){
				////						if(a[i]!=null){
				////							System.out.println(a[i]);
				////						}
				////							
				////						}
				////				}
				if(choice==2){
					a.displayA();
					break;
				}
				if(choice==3){
					a.updateA();

				}

				break;
			case 2:
				System.out.println("Add Book instance details");
				System.out.println("1.Add details");
				System.out.println("2.Display details");
				System.out.println("3.Update details");
				System.out.println("4.Delete details");

				System.out.println("Enter your choice");
				choice=sc.nextInt();
				if(choice==1){
					bi.addBI();
				}
				if(choice==2){
					bi.displayBI();
				}
				if(choice==3){
					bi.updateBI();
				}
				if(choice==4){
					bi.deleteBI();
				}
				break;
			
			case 3:
				System.out.println("Add Book details");
				System.out.println("1.Add details");
				System.out.println("2.Display details");
				System.out.println("3.Update details");
				System.out.println("4.Delete details");

				System.out.println("Enter your choice");
				choice=sc.nextInt();
				if(choice==1){
					b.addB();
				}
				if(choice==2){
					b.displayB();
				}
				if(choice==3){
					b.updateB();
				}
				if(choice==4){
					b.deleteB();
				}
				break;
			}

		}				



























	}
}

