package com.lti.bookStore.interfaces;

import java.sql.SQLException;

public interface Author_I {
   void addA() throws Exception ;
   void updateA() throws Exception;
   void displayA() throws Exception;
}
