package com.lti.bookStore.implementClasses;

import com.lti.bookStore.interfaces.Store_I;

public class Store_C implements Store_I{

	@Override
	public void addS() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateS() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayS() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteS() {
		// TODO Auto-generated method stub
		
	}

}
