package com.lti.bookStore.implementClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.bookStore.Jdbc.Jdbc_Connect;
import com.lti.bookStore.interfaces.Book_Instance_I;

public class Book_instance_C implements Book_Instance_I{
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	int choice=0;
	@Override
	public void addBI() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();			  
		PreparedStatement ps = con.prepareStatement("insert into book_instance values(?,?,?,?)");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		do{
			System.out.println("Enter copy instance");
			int id = Integer.parseInt(br.readLine());

			System.out.println("Enter Book Id");
			int bid = Integer.parseInt(br.readLine());

			System.out.println("Enter Order id");
			int oid = Integer.parseInt(br.readLine());

			System.out.println("Enter Stores id");
			int sid = Integer.parseInt(br.readLine());

			ps.setInt(1, id);
			ps.setInt(2,bid);
			ps.setInt(3, oid);
			ps.setInt(4, sid);

			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );

			System.out.println("do you want to continue: y/n");
			String s = br.readLine();
			if(s.startsWith("n")){
				break;
			}

		}while(true);
		con.close();


	}
		
	

	@Override
	public void updateBI() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();


		PreparedStatement ps = con.prepareStatement("update book_instance set book_id= ? where copy_instance = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));



		System.out.println("Enter copy instance");
		int id = Integer.parseInt(br.readLine());

		System.out.println("Enter Book Id");
		int bid = Integer.parseInt(br.readLine());
		ps.setInt(2, id);
		ps.setInt(1, bid);


		int i = ps.executeUpdate();
		System.out.println(i+ "records affected " );
		
	}

	@Override
	public void displayBI() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();

		Scanner sc = new Scanner(System.in);
		
		st=con.createStatement();
		System.out.println("Enter your choice");
		
	    int  choice = sc.nextInt();
	
			System.out.println("1.View all");
			System.out.println("2.View One");
			
			switch(choice)	


			{
	case 1:	 
		String q="Select * from book_instance";
	
	//to execute query
	ResultSet rs=st.executeQuery(q);
	
	//to print the resultset on console
	if(rs.next()){ 
		do{
			System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getString(3)+" " + rs.getString(4));
		
		}while(rs.next());
	}
	else{
		System.out.println("Record Not Found...");
	}
	con.close();
	break;
	case 2:
		PreparedStatement ps1 = con.prepareStatement("select * from book_instance where copy_instance = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter copy_instance");
		int id = Integer.parseInt(br.readLine());
		rs = ps1.executeQuery();
		while(rs.next()){
			System.out.println(rs.getInt(1)+" " + rs.getInt(2) +" "+ rs.getInt(3)+" " + rs.getInt(4));
		}
		break;
	}
}


	@Override
	public void deleteBI() throws SQLException, NumberFormatException, IOException {
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();


		PreparedStatement ps = con.prepareStatement("delete from Book_instance where book_id = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));




		System.out.println("Enter Book Id");
		int bid = Integer.parseInt(br.readLine());
	
		ps.setInt(1, bid);


		int i = ps.executeUpdate();
		System.out.println(i+ "records affected " );
	}
       
}
