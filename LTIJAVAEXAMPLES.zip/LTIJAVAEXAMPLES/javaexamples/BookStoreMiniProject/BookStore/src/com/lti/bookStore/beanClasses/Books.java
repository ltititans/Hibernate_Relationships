package com.lti.bookStore.beanClasses;

public class Books {
   private int ISBN;
   private String  book_title;
   private Author a;
   private Publisher p;
   public Books(){}
public Books(int iSBN, String book_title, Author a, Publisher p) {
	super();
	ISBN = iSBN;
	this.book_title = book_title;
	this.a = a;
	this.p = p;
}
public int getISBN() {
	return ISBN;
}
public void setISBN(int iSBN) {
	ISBN = iSBN;
}
public String getBook_title() {
	return book_title;
}
public void setBook_title(String book_title) {
	this.book_title = book_title;
}
public Author getA() {
	return a;
}
public void setA(Author a) {
	this.a = a;
}
public Publisher getP() {
	return p;
}
public void setP(Publisher p) {
	this.p = p;
}
@Override
public String toString() {
	return "Books [ISBN=" + ISBN + ", book_title=" + book_title + ", a=" + a + ", p=" + p + "]";
}

}
