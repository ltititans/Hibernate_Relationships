package com.lti.bookStore.implementClasses;

import com.lti.bookStore.interfaces.Publisher;

public class Publisher_C implements Publisher{

	@Override
	public void addP() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateP() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayP() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteP() {
		// TODO Auto-generated method stub
		
	}

}
