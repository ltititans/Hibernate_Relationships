package com.lti.bookStore.implementClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.bookStore.Jdbc.Jdbc_Connect;
import com.lti.bookStore.interfaces.Customers_I;

public class Customers_C implements Customers_I {
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	int choice=0;

	@Override
	public void addCI() throws SQLException, IOException {
		// TODO Auto-generated method stub
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();	
		PreparedStatement ps=con.prepareStatement("insert into CustomerTable values(?,?,?,?,?,?,?,?)");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do {
			System.out.println("enter the customer_id:");
			int id=	Integer.parseInt(br.readLine());
			System.out.println("enter the first_name:");
			String fname=br.readLine();
			System.out.println("enter last_name:");
			String lname=br.readLine();
			System.out.println("enter address:");
			String address=br.readLine();
			System.out.println("enter city:");
			String city=br.readLine();
			System.out.println("enter state:");
			String state=br.readLine();
			System.out.println("enter zipcode:");
			String zipcode=br.readLine();
			System.out.println("enter email_address:");
			String email=br.readLine();
			
			ps.setInt(1, id);
			ps.setString(2,fname);
			ps.setString(3,lname);
			ps.setString(4,address);
			ps.setString(5,city);
			ps.setString(6,state);
			ps.setString(7,zipcode);
			ps.setString(8,email);
			
			int i=ps.executeUpdate();
			System.out.println(i+"records affected");
			System.out.println("do you want to continue: y/n");
			String s=br.readLine();
			if(s.startsWith("n")){
				break;
			}

		}while(true);
		con.close();


	}

     @Override
	public void updateCI() throws SQLException, NumberFormatException, IOException {
    	 con=Jdbc_Connect.getConnect();
 		st=con.createStatement();	
 		PreparedStatement ps=con.prepareStatement("update Customer set fname =? where customer_id=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
			System.out.println("eneter the customer_id:");
			int id=	Integer.parseInt(br.readLine());
			System.out.println("enter new first name:");
			String fname=br.readLine();
			
			ps.setInt(2, id);;
			ps.setString(1, fname);
			
			int i=ps.executeUpdate();
			System.out.println(i+"records affected");

	}		
    	 
	

	@Override
	public void displayCI() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();	
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();
		Scanner sc = new Scanner(System.in);

		System.out.println("1.View all");
		System.out.println("2.View One");
		System.out.println("Enter your choice");

		choice = sc.nextInt();


		switch(choice)	


		{
		
		case 1:	 
			String q="Select * from customers";

			//to execute query
			ResultSet rs=st.executeQuery(q);

			//to print the resultset on console
			if(rs.next()){ 
				do{
					System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getString(3)+" " + rs.getString(4));

				}while(rs.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
			con.close();
			break;
		case 2:
			PreparedStatement ps1 = con.prepareStatement("select * from customers where customer_id = ?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("Enter customer_id");
			int id = Integer.parseInt(br.readLine());
			rs = ps1.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getString(3)+" " + rs.getString(4)+" " + rs.getString(5)+" " + rs.getString(6)+" " + rs.getString(7)+" " + rs.getString(8));
			}
			break;
		
		
		}
	}

	@Override
	public void deleteCI() throws SQLException, NumberFormatException, IOException {
		// TODO Auto-generated method stub
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();	
		PreparedStatement prest = con.prepareStatement("?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	 System.out.println("eneter the order_id to be deleted:");
	 int customer_id=Integer.parseInt(br.readLine());
	 prest.setInt(1, customer_id);
	  int del = prest.executeUpdate();
		
		
	}

}
