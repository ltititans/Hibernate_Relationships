package com.lti.bookStore.implementClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.lti.bookStore.Jdbc.Jdbc_Connect;
import com.lti.bookStore.interfaces.Order_Details_I;

public class Order_details_C implements Order_Details_I{
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	int choice=0;

	@Override
	public void addOD() throws SQLException, IOException {
		// TODO Auto-generated method stub
		con=Jdbc_Connect.getConnect();
		st=con.createStatement();	
		PreparedStatement ps=con.prepareStatement("insert into order_details values(?,?,?,?)");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do {
			System.out.println("eneter the order_detail_id:");
			int detail_id=	Integer.parseInt(br.readLine());
			System.out.println("Enter order id");
			int oid=Integer.parseInt(br.readLine());
			System.out.println("enter the price:");
			int price=	Integer.parseInt(br.readLine());
			
			System.out.println("enter discount:");
			int discount=Integer.parseInt(br.readLine());
			
			ps.setInt(1, detail_id);;
			ps.setInt(2,price);
			ps.setInt(3,discount );
		
			int i=ps.executeUpdate();
			System.out.println(i+"records affected");
			System.out.println("do you want to continue: y/n");
			String s=br.readLine();
			if(s.startsWith("n")) {
				break;
			}
		}while(true);}
		
		
	
	@Override
	public void updateOD() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayOD() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOD() {
		// TODO Auto-generated method stub
		
	}

}
