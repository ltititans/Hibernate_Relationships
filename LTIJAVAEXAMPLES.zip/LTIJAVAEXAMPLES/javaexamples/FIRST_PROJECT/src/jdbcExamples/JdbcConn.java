package jdbcExamples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConn {

	  public static void main(String[] args) throws SQLException, ClassNotFoundException {
		  System.out.println("Database Example");
		  Class.forName("oracle.jdbc.OracleDriver");
		Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123");
		System.out.println("Database Connected");
		conn.close();
		System.out.println("Connection Closed");
	}
}
