package jdbcExamples;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateEx {
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	
	public void add() throws SQLException
	{
		con=ConcClass.getConnect();
		st=con.createStatement();
	String str2="insert into mobile values(11111,'Appwl')";
	st.execute(str2);
	}
	public void update() throws SQLException
	{
		con=ConcClass.getConnect();
		st=con.createStatement();
		String str ="update  mobile set imei=2362728 where m_com='Appl'";
		rs=st.executeQuery(str);
		String str1 ="Select * from mobile";
		rs=st.executeQuery(str1);
		while(rs.next()){
			System.out.println(rs.getInt(1)+" : " +rs.getString(2));
		}
	}
		public void delete() throws SQLException
		{
			con=ConcClass.getConnect();
			st=con.createStatement();
			String str ="delete from mobile where imei=2132331";
			rs=st.executeQuery(str);
			String str3 ="Select * from mobile";
			rs=st.executeQuery(str3);
			while(rs.next()){
				System.out.println(rs.getInt(1)+" : " +rs.getString(2));
			}
		
	}

	public static void main(String[] args) throws SQLException  {
		// TODO Auto-generated method stub
            UpdateEx r=new UpdateEx();
            r.add();
            r.update();
            r.delete();
	}

}
