package jdbcExamples;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CallableStatement_Ex {
	public static void main(String[] args) throws SQLException {
		Connection con = ConcClass.getConnect();
		CallableStatement st = con.prepareCall("{call insert_product(?,?,?,?)}");
		st.setInt(1, 1011);
		st.setString(2, "Fogg");
		st.setInt(3, 165);
		st.setInt(4, 2782);
		st.execute();
		System.out.println("Success");
	}
	
}
