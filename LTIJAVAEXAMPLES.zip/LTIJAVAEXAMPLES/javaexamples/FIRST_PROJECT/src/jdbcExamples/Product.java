package jdbcExamples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Product {

	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	public void createProduct()
	{
		try
		{
			con=ConcClass.getConnect();
			st=con.createStatement();
			
			String str="create table product(product_id  number(5) primary key ,product_name varchar(50) unique not null,product_qty number(5),product_price number(8,2))";
			st.execute(str);
			System.out.println("Table Created ");
		}
		catch(Exception e)
		{
			System.out.println("Table already exists");
		}
	}
	public void insertProduct() throws SQLException, NumberFormatException, IOException
	{

		con=ConcClass.getConnect();
		st=con.createStatement();
	    
		PreparedStatement ps = con.prepareStatement("insert into product values(?,?,?,?)");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		do{
			System.out.println("Enter product_id");
			int id = Integer.parseInt(br.readLine());
			
			System.out.println("Enter product_name");
			String name = br.readLine();
			
			System.out.println("Enter product_qty");
			int qty = Integer.parseInt(br.readLine());
			
			System.out.println("Enter product_price");
			int price = Integer.parseInt(br.readLine());
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, qty);
			ps.setInt(4, price);
			
			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );
			
			System.out.println("do you want to continue: y/n");
			String s = br.readLine();
			if(s.startsWith("n")){
				break;
			}
			
		}while(true);
		con.close();
	}
	public void updateProduct() throws SQLException, NumberFormatException, IOException
	{

		con=ConcClass.getConnect();
		st=con.createStatement();
	

		PreparedStatement ps = con.prepareStatement("update product set product_name= ? where product_id = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		
	
			System.out.println("Enter product_id");
			int id = Integer.parseInt(br.readLine());
			
			System.out.println("Enter product_name");
			String name = br.readLine();
			
			ps.setInt(2, id);
			ps.setString(1, name);
		
			
			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );
		
	}
	public void deleteProduct() throws SQLException, NumberFormatException, IOException
	{

		con=ConcClass.getConnect();
		st=con.createStatement();
		
		PreparedStatement ps = con.prepareStatement("delete from product where product_id = ?");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter product_id");
		int id = Integer.parseInt(br.readLine());
		
		ps.setInt(1, id);
		int row = ps.executeUpdate();
		System.out.println(row + " Record deleted");
	
		

	}
	public void retrieveProduct() throws SQLException
	{
      System.out.println("abc");
		con=ConcClass.getConnect();
		st=con.createStatement();
		while(true)
		{
			System.out.println("1.View all");
			System.out.println("2.View One");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice)	
		
		
		{
		case 1:	PreparedStatement ps = con.prepareStatement("select * from product");
		rs = ps.executeQuery();
		while(rs.next()){
			System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getInt(3)+" " + rs.getInt(4));
		}
		break;
		case 2:
			PreparedStatement ps1 = con.prepareStatement("select * from product where product_id = ?");
			rs = ps1.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+" " + rs.getString(2) +" "+ rs.getInt(3)+" " + rs.getInt(4));
	}
		}
	}
	}
}
