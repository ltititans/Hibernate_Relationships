package jdbcExamples;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementEx {
	static Connection con=null;
	static Statement st=null;

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Database Example");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123");
			st=con.createStatement();
			try
			{
				String str="create table mobile(imei number(17),m_com varchar2(30))";
				st.execute(str);
				System.out.println("Table Created ");
			}
			catch(Exception e)
			{
				System.out.println("Table already exists");
			}
			String str="insert into mobile values(2132331,'Samsung')";
			st.execute(str);
			System.out.println("Data inserted");
		}
		
			finally 
				{
					con.close();
					st.close();
				}

			}	



		}
	

