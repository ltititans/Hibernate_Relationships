package jdbcExamples;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetEx {
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	public void fetch() throws SQLException
	{
		con=ConcClass.getConnect();
		st=con.createStatement();
		String str ="Select * from mobile";
		rs=st.executeQuery(str);
		
		while(rs.next()){
			System.out.println(rs.getInt(1)+" : " +rs.getString(2));
		}
		
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
      ResultSetEx r=new ResultSetEx();
      r.fetch();
	}

}
