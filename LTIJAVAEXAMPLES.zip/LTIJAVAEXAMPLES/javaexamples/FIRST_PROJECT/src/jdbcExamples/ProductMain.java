package jdbcExamples;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductMain {
	public static void main(String[] args) throws NumberFormatException, SQLException, IOException {
		Product p = new Product();
	
		while(true){
		Scanner sc=new Scanner(System.in);
		System.out.println("Input 1.Create Table 2.Insert Values 3.Update values 4.Delete row 5.Retrieve");
	
		int i=sc.nextInt();
		
		switch(i){
		case 1:	p.createProduct();
			break;
		case 2: p.insertProduct();
				break;
		case 3: p.updateProduct();
		   		break;
		case 4: p.deleteProduct();
		        break;
		case 5: p.retrieveProduct();
		        break;
		default:System.out.println("Invalid");
		}
	}}
}
