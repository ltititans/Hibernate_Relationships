
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 0120;
		int j = 07;
		System.out.println(i);
		System.out.println(j);

	}

}
