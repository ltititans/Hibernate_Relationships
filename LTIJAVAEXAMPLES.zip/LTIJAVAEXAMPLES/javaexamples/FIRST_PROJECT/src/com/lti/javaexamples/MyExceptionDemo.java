package com.lti.javaexamples;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class MyExceptionDemo {
	static int flag=0;
  public static void main(String[] args) {
	try{
		int age=Integer.parseInt(args[0]);
		if(age <18)
		throw new MyException();
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		flag=1;
		System.out.println("Exception"+e);
	}
	catch(NumberFormatException e)
	{
		flag=1;
		System.out.println("Exception: "+e);
	}
	catch(MyException e){
		flag=1;
		System.out.println("Exception :"+e);
	}
	if(flag==0)
	{
		System.out.println("Everything is fine");  
	}
}
}
