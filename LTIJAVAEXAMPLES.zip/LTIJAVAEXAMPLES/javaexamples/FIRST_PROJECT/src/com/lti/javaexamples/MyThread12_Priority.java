package com.lti.javaexamples;



class priorityThreadA extends Thread
{
	public void run()
	{
		System.out.println("Thread A Started");
		for(int i=2;i>0;i--)
		{
			System.out.println("From ThreadA : I ="+i);
		}
		System.out.println("existing");
	}
}
class priorityThreadB extends Thread
{
	public void run()
	{
		System.out.println("Thread B Started");
		for(int j=2;j>0;j--)
		{
			System.out.println("From ThreadB : I ="+j);
		}
		System.out.println("existing");
	}
}
class priorityThreadC extends Thread
{
	public void run()
	{
		System.out.println("Thread C Started");
		for(int k=2;k>0;k--)
		{
			System.out.println("From ThreadC : I ="+k);
		}
		System.out.println("existing");
	}
}
public class MyThread12_Priority {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		priorityThreadA t1= new priorityThreadA();
		priorityThreadB t2=new priorityThreadB();
		priorityThreadC t3= new priorityThreadC();
		try{
			t1.setPriority(Thread.NORM_PRIORITY+1);
			t1.start();
			t1.join();
			
			t2.setPriority(Thread.NORM_PRIORITY-2);
			t2.start();
			
			t3.setPriority(Thread.NORM_PRIORITY+4);
			t3.start();
			
		}
		catch(Exception e)
		{
			
		}
	}

}
