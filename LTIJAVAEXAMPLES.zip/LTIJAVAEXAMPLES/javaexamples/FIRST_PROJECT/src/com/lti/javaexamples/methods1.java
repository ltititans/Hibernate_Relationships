package com.lti.javaexamples;

import java.util.Scanner;

class methods_1 {
	
	public void pallindrome()
	{
		String a,b="";
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the string you want to check:");
		a=s.nextLine();
		int n=a.length();
		for(int i=n-1;i>=0;i--)
		{
			b=b+a.charAt(i);
		
		}
		if(a.equalsIgnoreCase(b))
		{
			System.out.println("The String is pallindrome");
		}
		else
		{
			System.out.println("The String is not pallindrome");
		}
		
	}
	
	public void fibonacci()
	{
	
		
		Scanner sc=new Scanner(System.in);
		int a=0,b=1,c=0;
		System.out.println("Enter the limit");
		int n=sc.nextInt();

		for(int i=0;i<n;i++){
			System.out.println(a);
			c=a+b;
			a=b;
			b=c;
		}
	}
	
public void addition()
{
	
	Scanner ob=new Scanner(System.in);

	System.out.println("Enter the number of rows and columns:");
	int m=ob.nextInt();
	int n=ob.nextInt();
	int a[][]=new int[m][n];
	int b[][]=new int[m][n];
	int c[][]=new int[m][n];
	System.out.println("Enter first matrix:");
	for(int i=0;i<m;i++)
	{
	 for (int j=0;j<n;j++)
	 {
	    a[i][j]=ob.nextInt();
	}
	}
	System.out.println("Enter second matrix:");
	for(int i=0;i<m;i++)
	{
	 for (int j=0;j<n;j++)
	 {
	    b[i][j]=ob.nextInt();
	}
	}
	System.out.println("Addition is:");
	for(int i=0;i<m;i++)
	{
	 for (int j=0;j<n;j++)
	 {
	    c[i][j]=a[i][j]+b[i][j];
			
	}
	}
	for(int i=0;i<m;i++)
	{
	 for (int j=0;j<n;j++)
	 {
	System.out.print( c[i][j]+" ");
	}
	System.out.println();
	}
}


 public void multiplication()
 {
	 Scanner ob=new Scanner(System.in);

	 System.out.println("Enter the number of rows and columns:");
	 int m=ob.nextInt();
	 int n=ob.nextInt();
	 int a[][]=new int[m][n];
	 int b[][]=new int[m][n];
	 int c[][]=new int[m][n];
	 System.out.println("Enter first matrix:");
	 for(int i=0;i<m;i++)
	 {
	  for (int j=0;j<n;j++)
	  {
	     a[i][j]=ob.nextInt();
	 }
	 }
	 System.out.println("Enter second matrix:");
	 for(int i=0;i<m;i++)
	 {
	  for (int j=0;j<n;j++)
	  {
	     b[i][j]=ob.nextInt();
	 }
	 }
	 System.out.println("Multiplication  is:");
	 for(int i=0;i<m;i++)
	 {
	  for (int j=0;j<n;j++)
	  {
	     c[i][j]=0;
	 	for(int k=0;k<n;k++)
	 		{
	 			c[i][j]=c[i][j] + a[i][k]*b[k][j];
	 		}
	 }
	 }
	 		
	 for(int i=0;i<m;i++)
	 {
	  for (int j=0;j<n;j++)
	  {
	 System.out.print( c[i][j]+" ");
	 }
	 System.out.println();
	 }
	 }
	 
 public void prime(int n)
	{
		int flag=1;
     for(int i=2;i<n/2;i+=1)
	{
		if(n%i==0)
			flag=0;
         break;
		
	}
	if(flag==0)
	{
		System.out.println(n+"not  a prime number");
	}
	else
		System.out.println(n+"is a prime number");
	}
  
}
public class methods1 {

	public static void main(String[] args)
	{
       methods_1 m=new methods_1();
       int c;
       while(true)
       {
       System.out.println("Choices are");
       System.out.println("1.Addition of matrix \n 2. Multiplication of matrix \n 3. Prime number\n 4. Fibonacci series 5.Palindrome \n");
      
       System.out.println("Enter your choice");
       Scanner in =new Scanner(System.in);
       
       c=in.nextInt();
      
       switch(c)
       {
       case 1: m.addition();
               break;
       case 2: m.multiplication();
               break;
        case 3: int n;
                System.out.println("enter n\n");
                Scanner i=new Scanner(System.in);
                n=i.nextInt();
        	    m.prime(n);
                break;
        case 4: 
        	    m.fibonacci();
                 break;
        case 5: 
        	   
              	m.pallindrome();
                break;
        case 6:
        	System.exit(0);
                default:System.out.println("Invalid choice"); 
       }
                
       }
	}
}

 


