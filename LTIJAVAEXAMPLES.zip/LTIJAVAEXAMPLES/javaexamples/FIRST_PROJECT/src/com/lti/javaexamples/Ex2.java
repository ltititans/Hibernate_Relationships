package com.lti.javaexamples;

public class Ex2 {
   public static void main(String[] args) {
	try{
		int i=Integer.parseInt(args[0]);
		System.out.println(i);
	}
	catch(RuntimeException e){
		System.out.println(e);
	}
	
//	catch (NumberFormatException p) {
//		// TODO: handle exception
//		System.out.println(p);
//	}
}
}
