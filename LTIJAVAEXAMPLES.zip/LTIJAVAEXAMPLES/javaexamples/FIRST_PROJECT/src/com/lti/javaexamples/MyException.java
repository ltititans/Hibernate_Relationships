package com.lti.javaexamples;

public class MyException extends Exception {
	MyException()
	{
		System.out.println("User defined Exception thrown");
	}
	public String   toString()
	{
	   return"My Exception object :Age Cannot be<18";
	   
	}

}
