package com.lti.javaexamples;

class MyThread1 extends Thread
{
	  public MyThread1(String threadName)
	  {
		  super(threadName);
		  System.out.println(threadName);
	  }
//	public void run()
//	{
//		for(int i=0;i<11;i++){ 
//			System.out.println(i+ "   "+getName());
//			try
//			{
//				sleep((long)(Math.random()*3000));
//			}
//			catch(InterruptedException e)
//			{
//				
//			}
//		}
//	}
}


public class MyThreadEx12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      MyThread1 t= new  MyThread1("Sudeepth");
      t.start();
      t.run();
      MyThread1 t1= new  MyThread1("R");
      t1.start();
	}

}
