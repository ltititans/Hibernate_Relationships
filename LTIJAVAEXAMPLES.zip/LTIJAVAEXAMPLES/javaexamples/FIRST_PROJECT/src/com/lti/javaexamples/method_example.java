package com.lti.javaexamples;

 class methodexample {
 
	private int a;
	private int b;
	
	public void add(int a,int b){
		this.a=a;
		this.b=b;
		System.out.println(a+b);
	}

	public int subtract(int i,int j){
		this.a=i;
		this.b=j;
		return i-j;
	}
}

	public class method_example
	{
		 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        methodexample n=new methodexample();
        n.add(10, 20);
        System.out.println(n.subtract(20, 90));
      	}
}

