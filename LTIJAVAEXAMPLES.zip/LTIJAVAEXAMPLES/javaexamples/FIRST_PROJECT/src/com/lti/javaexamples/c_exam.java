package com.lti.javaexamples;

public class c_exam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            
	}

}
