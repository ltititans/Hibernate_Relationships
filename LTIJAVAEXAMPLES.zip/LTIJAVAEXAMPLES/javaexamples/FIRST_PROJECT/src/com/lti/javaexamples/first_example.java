package com.lti.javaexamples;

public class first_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            System.out.println("Hello cheta");
	}

}
