package com.lti.javaexamples;

public class rectangle {
	
	double width;
	double breadth;
	double area;
	public rectangle() {
		// TODO Auto-generated constructor stub
             width=1;
             breadth=1;
	}
	public rectangle(double width,double breadth) {
		// TODO Auto-generated constructor stub
            this. width=width;
             this.breadth=breadth;
	}
	void display()
	{
		System.out.println("Width="+width+"\n"+"Breadth="+breadth);
	}
	void area()
	{
		area=width*breadth;
		System.out.println("Area="+area);
	}
	

}
