package com.lti.javaexamples;

import java.util.Scanner;

public class calrect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       double width;
       double breadth;
       System.out.println("Enter width");
       Scanner w=new Scanner(System.in);
       width=w.nextDouble();
       System.out.println("Enter breadth");
       Scanner b=new Scanner(System.in);
       breadth= w.nextDouble();
       if(width<=0 && breadth<=0)
       {
       rectangle r= new rectangle();
       r.display();
       r.area();
       }
       else
       {
       rectangle r1= new rectangle(width,breadth);
       r1.display();
       r1.area();
	}
	}

}
