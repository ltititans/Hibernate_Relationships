package com.lti.javaexamples;

public class Static_Example {
      static int i=10;
      static int j=10;
      int k=90;
      static
      {
    	  System.out.println("static block invoked"+(i+j));
      }
      public static void display(){
    	  System.out.println("Static  method Invoked"+"Last :"+(i+j));
      }
      public static void main(String args[])
      {
    	  System.out.println("Static main method Invoked"+"After Static Block :"+(i+j));
    	  display();
      }
}
