package com.lti.javaexamples;

import com.lti.javaexamples.A.NestedIf;

public class NestedIFDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          A.NestedIf nif =new B();
           
           
           if(nif.isNotNegative(-10))
           {
        	   System.out.println("10 is not negative");
           }
           else if(nif.isNotNegative(12))
           {
        	   System.out.println("this won't be displayed");
           }
           else if(nif.isNotNegative(-12))
           {
        	   System.out.println("10 is not negative");
           }
           
	}

}
