package com.lti.javaexamples;

interface B1{
	
	 public void method();
}
public class Interface_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b = new B1(){
			public void method(){
				System.out.println("I am an Anonymous class of method");
			}
		};
        
	}

}
