package com.lti.javaexamples;
import java.util.InputMismatchException;
import java.util.Scanner;

class MatExc {
	
	public static int read(){
		int va=3;
		Scanner sc=new Scanner(System.in);

		try{
			System.out.println("enter the value");
			va=sc.nextInt();
			return va;
		}catch(InputMismatchException e){
			System.out.println("read only integers");
			va=read();
		}
		return va;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		n=read();
		int a[][]=new int[n][n];
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				System.out.println("enter the matrix");
				a[i][j]=read();
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				System.out.println(" the matrix:"+a[i][j]);
				
			}
		}
	}

}
