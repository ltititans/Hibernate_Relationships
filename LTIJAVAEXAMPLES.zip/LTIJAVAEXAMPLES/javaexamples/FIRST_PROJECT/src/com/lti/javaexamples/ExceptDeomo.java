package com.lti.javaexamples;

public class ExceptDeomo {
  public static void main(String[] args) {
	int x,a;
	try
	{
		x=0;
		a=22/x;
		System.out.println("This will be Bypassed.");
	
	}  
//  catch(ArithmeticException e){
//	  System.out.println("Divison by Zero");
   finally {
	System.out.println("After catch Statement");
   }
  }
}
