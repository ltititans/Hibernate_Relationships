package com.lti.javaexamples;

 class Thread1 extends Thread{
     public void run(){
    	 System.out.println("First thread example "+Thread.currentThread());
     }
}



