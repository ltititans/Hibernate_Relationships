package com.lti.javaexamples;

public class ComputerTable {
	
	
    double width;
    double breadth;
    double feet;
    public ComputerTable( double a,double b,double c) {
		// TODO Auto-generated constructor stub
    	this.width=a;
    	this.breadth=b;
    	this.feet=c;
    	
	}
    void display()
    {
    	System.out.println("Width="+width+"\n"+"Breadth="+breadth+"\n"+"Feet="+feet);
    }
	

	}


