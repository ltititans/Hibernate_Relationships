package com.lti.javaexamples;


import java.io.FileNotFoundException;
import java.util.*;

public class ThrowDemo {
	static void throwOne() throws FileNotFoundException{
		System.out.println("Inside throwOne");
		throw new FileNotFoundException();
	}
     public static void main(String[] args) {
		try{
			throwOne();
		}
		catch(FileNotFoundException e){
			System.out.println("Caught "+e);
		}
		
		finally{
			System.out.println("exception caught");
		}
	}
}
