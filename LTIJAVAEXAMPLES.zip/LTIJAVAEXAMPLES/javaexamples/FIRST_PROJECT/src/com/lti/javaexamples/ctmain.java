package com.lti.javaexamples;

public class ctmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ComputerTable i=new ComputerTable(3,4,2.5);
       i.display();
	}

}
