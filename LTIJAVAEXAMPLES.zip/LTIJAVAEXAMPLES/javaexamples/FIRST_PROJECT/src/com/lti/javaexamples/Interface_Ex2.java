package com.lti.javaexamples;
interface B2{
	
	 public void method();
	 public  void method2();
}

class Ab{
	B2 b = new B2(){
		public void method(){
			System.out.println("I am an anonymous class");
		}
		public void method2(){
			System.out.println("I am an anonymous class of method2");
		}
	};
}
public class Interface_Ex2 {
     public static void main(String[] args) {
		Ab  c =null;
		c.b.method();
		c.b.method2();
		//Interface_Ex2 e  = new Interface_Ex2();
	}
}
