package com.lti.javaexamples;

public class Constructor_Ex {
	  
	public Constructor_Ex(int a,int b) {
		// TODO Auto-generated constructor stub
	    System.out.println("Integer Construct");
	
	
	}
	public Constructor_Ex(double a,double b) {
		// TODO Auto-generated constructor stub
	  System.out.println("Double Constructor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Constructor_Ex i=new Constructor_Ex(1, 2);
	}

}
