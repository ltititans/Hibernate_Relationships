package com.lti.javaexamples;

public class Exception_Ex {

	static void disp()
	{try
	{
		
			int a[]={2,4,5,6};
		System.out.println(a[4]);
	}
	
	catch(Exception e)
	{
	    e.printStackTrace();
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Exception_Ex.disp();
	}

}
