package com.lti.javaexamples;


class print
{
	 void printing(String name)
	{
		System.out.print("["+name);
		Thread.yield();
		System.out.println("]");
	}
}

class MyThread implements Runnable
{
	String name;
	print target;
	MyThread(print t)
	{
		target=t;
	}
	public void run()
	{
		name=Thread.currentThread().getName();
		target.printing(name);
	}
}
class ThreadMain
{
	public static void main(String args[]) {
		print t=new print();
		for(int i=0;i<5;i++)
			new Thread(new MyThread(t)).start();
	}
}
///////////////////synced////////////////////////////////




public class MyThread13 implements Runnable{

	 String name;
	 print target;
	 MyThread13(print t)
	 {
		 target=t;
	 }
	@Override
	public void run() {
		// TODO Auto-generated method stub
		name = Thread.currentThread().getName();
		target.printing(name);
		
	}

	class Synche
	{
		
			
		}
	}
	

