package com.lti.javaexamples;
class Thread12 implements Runnable{

	Thread12(String threadName)
	{
		System.out.println(threadName);
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<4;i++){
			System.out.println(Thread.currentThread());
			try
			{
				Thread.sleep((long)(Math.random()*6000));
			}catch(InterruptedException e){}
		}
	}
	
}
public class MyThread12 {

	public static void main(String[] args)  throws InterruptedException{
		// TODO Auto-generated method stub

		Thread12 t=new Thread12("Sudeepth");
		Thread mt=new Thread(t);
		mt.setName("Sudeepth");
		mt.start();
		mt.join();
		
		Thread12 t1=new Thread12("Sen");
		Thread mt1=new Thread(t);
		mt1.setName("Sen");
		mt1.start();
		
		
		Thread12 t2=new Thread12("Sena");
		Thread mt2=new Thread(t);
		mt2.setName("Sena");
		mt2.start();
		
	
	}

}
