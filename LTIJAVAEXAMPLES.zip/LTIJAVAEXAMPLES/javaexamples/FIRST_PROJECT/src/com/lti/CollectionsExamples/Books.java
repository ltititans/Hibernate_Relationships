package com.lti.CollectionsExamples;

public class Books implements Comparable<Books> {
	private int isbn;
	private int author_id;
	private int p_id;
	private String b_name;
	public Books(int isbn, int author_id, int p_id, String b_name) {
		this.isbn = isbn;
		this.author_id = author_id;
		this.p_id = p_id;
		this.b_name = b_name;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public int getAuthor_id() {
		return author_id;
	}
	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	@Override
	public String toString() {
		return "Books [isbn=" + isbn + ", author_id=" + author_id + ", p_id=" + p_id + ", b_name=" + b_name + "]";
	}
	@Override
	public int compareTo(Books o) {                                                                                                                                                                                                                                              
		// TODO Auto-generated method stub
		return (int) o.isbn -  this.isbn;
	}

}
