package com.lti.CollectionsExamples;

import java.util.Comparator;

public class SortByTitle implements Comparator<Book1> {

	@Override
	public int compare(Book1 o1, Book1 o2) {
		// TODO Auto-generated method stub
		return   o1.getIsbn() - (o2.getIsbn());
	}

}
