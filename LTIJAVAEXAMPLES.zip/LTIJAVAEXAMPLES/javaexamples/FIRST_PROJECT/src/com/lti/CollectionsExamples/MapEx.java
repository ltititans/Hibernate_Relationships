package com.lti.CollectionsExamples;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapEx {
 public static void main(String[] args) {
	Map<String, Employee> emap = new HashMap<String,Employee>();
	emap.put("M1", new Employee(101, "Sudeepth"));
	emap.put("M2", new Employee(102, "Rishi"));
	emap.put("M3", new Employee(103, "Rishikesh"));
	Employee emp=(Employee) emap.get("m1");
	System.out.println(emp);
	Iterator<String> iter =emap.keySet().iterator();
	while(iter.hasNext()){
		String id=iter.next();
		System.out.println(id);
	}
	Set<Map.Entry<String, Employee>> entrySet =emap.entrySet();
	for(Map.Entry<String, Employee> entry : entrySet)
	{
		System.out.println(entry.getKey() + "---->" + entry.getValue());
	}
}
}
