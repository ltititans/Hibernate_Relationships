package com.lti.CollectionsExamples;

import java.util.ArrayList;
import java.util.List;

public class Generic_Ex {
    public static void main(String[] args) {
		
	
 	List<String>  strList= new ArrayList<String>();
 	strList.add(new String("Rahul"));
 	strList.add(new String("Rahul"));
 	strList.add(new String("Rahul"));
 	//strList.add(new Date("Rahul"));
    }
}
