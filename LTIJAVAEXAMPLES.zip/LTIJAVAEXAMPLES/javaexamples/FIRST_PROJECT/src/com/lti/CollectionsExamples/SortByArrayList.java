package com.lti.CollectionsExamples;

import java.util.Comparator;

public class SortByArrayList implements Comparator<Book1>{

	@Override
	public int compare(Book1 o1, Book1 o2) {
		// TODO Auto-generated method stub
		return  o1.getB_name().compareTo(o2.getB_name());
	}
	

}
