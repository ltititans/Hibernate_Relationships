package com.lti.CollectionsExamples;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Iterator_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> flavours = new ArrayList<String>();
		flavours.add("chocolate");
		flavours.add("vanilla");
		flavours.add("strawberry");
		Collections.sort(flavours);
		Iterator<String> flavourIter = flavours.iterator();
		while(flavourIter.hasNext()){
			System.out.println(flavourIter.next());
		}
		
		

	}

}
