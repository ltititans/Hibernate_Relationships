package com.lti.CollectionsExamples;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ArrList_Example {
  
	public static void main(String[] args) {
		
	
	List list = new ArrayList();
	list.add(new String("Java"));
	list.add(new Integer(22));
	list.add(new Date());
	list.add(new String("Hello"));
	Date d=(Date) list.get(2);
	System.out.println(d);
	System.out.println(list.get(0));
	for(int i=0;i< list.size();i++)
	{
		if(list.get(i) instanceof String){
			String str = (String) list.get(i);
			System.out.println(str);
		}
		list.add("nair");
	}
	
	}
	
}
