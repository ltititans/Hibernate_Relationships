package com.lti.CollectionsExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> flavours = new TreeSet<String>();
		flavours.add("chocolate");
		flavours.add("vanilla");
		flavours.add("strawberry");
		flavours.add("strawberry");
		
		Iterator<String> flavourIter = flavours.iterator();
		while(flavourIter.hasNext()){
			System.out.println(flavourIter.next());
		}
		
		

	}
}
