package com.lti.CollectionsExamples;

import com.lti.abstractexamples.A1;

public class A2 extends A1{
public static void main(String[] args) {
	A1 a=new A1();
	a.display();
	
}
}
