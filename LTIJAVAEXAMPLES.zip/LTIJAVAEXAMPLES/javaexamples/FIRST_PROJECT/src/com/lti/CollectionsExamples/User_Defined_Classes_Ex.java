package com.lti.CollectionsExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import com.lti.CollectionsExamples.Book1;

public class User_Defined_Classes_Ex {

	
	
	public static void book_info(){
		Book1 b=new Book1();
		// TODO Auto-generated method stub
		int isbn,author_id,p_id;
		b.setAuthor_id(1);
		b.setB_name("dfd");
		b.setP_id(23);
		b.setIsbn(55);
		
		String b_name=b.getB_name();
		isbn=b.getIsbn();
		author_id=b.getAuthor_id();
		p_id=b.getP_id();
		Set<Book1> li = new HashSet<Book1>();
		li.add(new Book1( isbn,  author_id,  p_id,  b_name));
		li.add(new Book1(12343322, 1103, 322, "Mossad"));
		li.add(new Book1(12343323, 1100, 323, "KGB"));
		li.add(new Book1(12343323 , 1100, 323, "KGB"));
		System.out.println("Sort By ISbn");
//		Collections.sort(li,new SortByArrayList());
		Iterator<Book1> itr = li.iterator();
		while(itr.hasNext()){
			Book1 b1 = itr.next();
			System.out.println(b1);
		}
			
			System.out.println("Sort By Title");	
			
//			Collections.sort(li,new SortByTitle());
			Iterator<Book1> itr1 = li.iterator();
			while(itr1.hasNext()){
				Book1 b1 = itr1.next();
				System.out.println(b1);
		}

	}
	public static void main(String[] args) {
		book_info();
	}

}
