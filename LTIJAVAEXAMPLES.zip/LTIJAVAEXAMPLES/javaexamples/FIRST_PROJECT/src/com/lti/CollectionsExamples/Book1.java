package com.lti.CollectionsExamples;

public class Book1 {
	private int isbn;
	private int author_id;
	private int p_id;
	private String b_name;
	public Book1(){}  
	

	public Book1(int isbn, int author_id, int p_id, String b_name) {
		this.isbn = isbn;
		this.author_id = author_id;
		this.p_id = p_id;
		this.b_name = b_name;
	}
	public int getIsbn() {
		return isbn;
	}
	
	
	
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	
	public int getAuthor_id() {
		return author_id;
	}
	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	@Override
	public String toString() {
		return "Books [isbn=" + isbn + ", author_id=" + author_id + ", p_id=" + p_id + ", b_name=" + b_name + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + author_id;
		result = prime * result + ((b_name == null) ? 0 : b_name.hashCode());
		result = prime * result + isbn;
		result = prime * result + p_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book1 other = (Book1) obj;
		if (author_id != other.author_id)
			return false;
		if (b_name == null) {
			if (other.b_name != null)
				return false;
		} else if (!b_name.equals(other.b_name))
			return false;
		if (isbn != other.isbn)
			return false;
		if (p_id != other.p_id)
			return false;
		return true;
	}
	
	
	

}
