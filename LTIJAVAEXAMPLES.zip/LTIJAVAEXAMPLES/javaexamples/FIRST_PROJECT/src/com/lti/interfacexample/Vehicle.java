package com.lti.interfacexample;

public class Vehicle implements Engine{
  int speed;
  int gear;
@Override
public void changeGear(int a) {
	// TODO Auto-generated method stub
	this.speed = a;
	System.out.println("speed " +speed);
}
@Override
public void speedUp(int a) {
	// TODO Auto-generated method stub
	this.gear = a;
	System.out.println("gear " +gear);
}
public static void main(String aregs[]){
	Vehicle v = new Vehicle();
	v.changeGear(5);
	v.speedUp(100);
}
  
}
