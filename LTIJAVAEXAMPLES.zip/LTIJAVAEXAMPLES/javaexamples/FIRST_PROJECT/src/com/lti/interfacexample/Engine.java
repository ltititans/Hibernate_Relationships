package com.lti.interfacexample;

public interface Engine {
	void changeGear(int a);
	void speedUp(int a);

}
