package com.lti.Java8Ex;
@FunctionalInterface
public interface FunctionalInterfaceIntf {

	public void display();
}


@FunctionalInterface
interface ParamFuncInterface{
	public String show(String name1);
}


@FunctionalInterface
interface AddParam{
	public int add(int a,int b);
}
