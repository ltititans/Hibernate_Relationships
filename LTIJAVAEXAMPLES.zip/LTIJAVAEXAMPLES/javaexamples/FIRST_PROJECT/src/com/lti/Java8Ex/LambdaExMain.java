package com.lti.Java8Ex;

public class LambdaExMain {
   public static void main(String[] args) {
	String name = "sush";
	FunctionalInterfaceIntf f = ()->{
		System.out.println("Hi "+name);
		};
	f.display();
	ParamFuncInterface p = (name1)->{return "Hi "+name1;};
	System.out.println(p.show("Akshay"));
	ParamFuncInterface p1 = (name1)->{return "Hi "+name1;};
	System.out.println(p1.show("koli"));
	AddParam ad=(a,b)->{return a+b;};
	System.out.println(ad.add(3, 5));
	
	
}
 
   
}
