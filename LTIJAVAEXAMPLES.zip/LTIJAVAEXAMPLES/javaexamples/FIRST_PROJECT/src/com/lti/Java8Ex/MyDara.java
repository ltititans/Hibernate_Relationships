package com.lti.Java8Ex;

public interface MyDara {

	default void print(String str) {
		if (true)
			System.out.println("Mydata  ::" +str);
	}

}
