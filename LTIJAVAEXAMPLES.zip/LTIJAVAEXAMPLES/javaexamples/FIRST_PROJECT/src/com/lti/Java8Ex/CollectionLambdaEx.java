package com.lti.Java8Ex;

import java.util.ArrayList;
import java.util.List;

public class CollectionLambdaEx {

	
	public static void main(String[] args) {
		List<String> p1=new ArrayList<>();
		p1.add("1");
		p1.add("2");
		p1.forEach(p->{
			System.out.println(p);
		});
	}
}
