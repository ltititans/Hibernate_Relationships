package com.lti.Java8Ex;

public interface A {
     default void foo()
     {
    	 System.out.println(" Calling A.foo() ");
     }
     public static void dadda()
     {
    	 System.out.println("hi mibba");
     }
 
}
