package com.lti.Java8Ex;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Employ {

     public static void main(String[] args) {
		
	 List<Employee> l = new ArrayList<Employee>();
	  l.add(new Employee(101,"Shan",1200.00));
	  l.add(new Employee(103,"Amit",1230.00));
	  l.add(new Employee(102,"Raaj",1100.50));
	  l.add(new Employee(104,"Akshay",50000.00));
	  
	  System.out.println("Salary with 10% hike \n");
	  l.forEach(e -> e.setSalary(e.getSalary()*11/10));
	  System.out.println(l);
	  
	  System.out.println("\n Salary greater than Specific amount\n");
	  List<Employee> li = l.stream().filter(e -> e.getSalary() > 1300).collect(Collectors.toList());
	  System.out.println(li);
	  
	  System.out.println("\nsorting based on name");
	  List<Employee> lii = l.stream().sorted().collect(Collectors.toList());
	  System.out.println(lii);
	  
	  
     }
	  
}
