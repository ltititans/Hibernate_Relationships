package com.lti.Java8Ex;

public interface MyData {

	
		default void print(String str) {
			if (! isNull(str))
				System.out.println("Mydata print ::" +str);
		}

		static boolean isNull(String str) {
			System.out.println("Interface null check");
			return str == null ? true : "".equals(str) ? true : false ;
		}

}
