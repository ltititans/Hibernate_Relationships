package com.lti.Java8Ex;

public class LambdaExpressionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          new Thread(new Runnable()
        		  {
        	  public void run()
        	  {
        		  System.out.println("Runnable usomg anonymous Class");
        	  }
        		  }).start();
        		  new Thread(
        				  () ->{
        					  System.out.println("Running using lambda expression");
        				  }
        				  ).start();
		
		
	}

}
