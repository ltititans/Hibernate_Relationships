package com.lti.javaexamples1;

public class Private implements Salary{
	double basic,hra,da,salary;
	@Override
	public void salDetails(double basic) {
		// TODO Auto-generated method stub
		this.basic=basic;
		hra=0.5*basic;
		da=0.1*basic;
		salary=basic+hra+da;
			System.out.println("Gross salary private sector is:"+basic);
			System.out.println("Net salary  private sector is :"+salary);
	}

}
