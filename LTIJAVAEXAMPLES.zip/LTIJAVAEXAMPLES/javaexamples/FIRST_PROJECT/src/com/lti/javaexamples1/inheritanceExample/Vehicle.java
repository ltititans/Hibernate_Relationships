package com.lti.javaexamples1.inheritanceExample;

public class Vehicle {
	  public void start()
	  {
		  System.out.println("Start Method");
	  }
	  public  void stop()
	  {
		  System.out.println("Stop Method");
	  }
	  public void turn(String v)
	  {
		  System.out.println(v+"turn Method");
	  }

}
class Bike extends Vehicle{
	public void start()
	  {
		  System.out.println("Start Method for Bike");
	  }
	  public void stop()
	  {
		  System.out.println("Stop Method for Bike");
	  }
	 
}