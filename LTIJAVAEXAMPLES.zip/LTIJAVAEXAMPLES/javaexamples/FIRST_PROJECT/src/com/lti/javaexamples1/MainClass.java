package com.lti.javaexamples1;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the  basic salary");
	double basic=sc.nextDouble();
	if((basic>=20000)&&(basic<50000)) {
		State sg=new State();
		sg.salDetails(basic);
	}
	else if((basic>=50000)&&(basic<80000)) {
		Central cg=new Central();
		cg.salDetails(basic);
	}
	else if((basic>=80000)&&(basic<100000)) {
		Private pg=new Private();
		pg.salDetails(basic);
	}
}
}