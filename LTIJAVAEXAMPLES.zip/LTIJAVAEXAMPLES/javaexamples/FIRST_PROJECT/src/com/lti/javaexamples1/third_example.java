package com.lti.javaexamples1;

import com.lti.javaexamples.first_example;

public class third_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Default package implementation is same package");
	      first_example f= new first_example();
	}

}
