package com.lti.javaexamples1;

public class State implements Salary {
	double basic,hra,da,salary;
	@Override
	public void salDetails(double basic) {
		// TODO Auto-generated method stub
		this.basic=basic;
		hra=2.5*basic;
		da=0.3*basic;
		salary=basic+hra+da;
			System.out.println("Gross salary of State Govt is:"+basic);
			System.out.println("Net salary of State Govt is :"+salary);
	}

}
