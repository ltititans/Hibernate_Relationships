package com.lti.javaexamples1;

public interface Salary {

	void salDetails(double basic);
}
