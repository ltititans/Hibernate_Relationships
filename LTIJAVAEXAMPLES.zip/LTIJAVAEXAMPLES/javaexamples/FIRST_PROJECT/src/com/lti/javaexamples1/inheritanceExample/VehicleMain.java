package com.lti.javaexamples1.inheritanceExample;

public class VehicleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Vehicle v=new Vehicle();
       v.turn("right");
       Bike b =new Bike();
       b.turn("left");
       b.start();
       b.stop();
	}

}
