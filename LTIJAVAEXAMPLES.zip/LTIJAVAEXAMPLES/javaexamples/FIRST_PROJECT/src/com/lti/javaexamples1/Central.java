package com.lti.javaexamples1;

public class Central implements Salary {
   double basic,hra,da,salary;
	@Override
	public void salDetails(double basic) {
		// TODO Auto-generated method stub
		this.basic=basic;
		hra=0.4*basic;
		da=0.8*basic;
		salary=basic+hra+da;
			System.out.println("Gross salary Central Govt is:"+basic);
			System.out.println("Net salary Central Govt is :"+salary);
	}

}
