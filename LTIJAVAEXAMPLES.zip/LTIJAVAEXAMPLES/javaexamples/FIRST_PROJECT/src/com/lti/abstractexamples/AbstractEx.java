package com.lti.abstractexamples;

public class AbstractEx extends Sum {
	
	public int sumofTwo(int num1,int num2)
	{
		return num1+num2;
	}
	public int sumofThree(int num1,int num2,int num3)
	{
		return num1+num2+num3;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Sum obj = new AbstractEx();
       obj.display();
       System.out.println(obj.sumofTwo(3, 7));
       System.out.println(obj.sumofThree(4, 3, 19));
       
	}

}
