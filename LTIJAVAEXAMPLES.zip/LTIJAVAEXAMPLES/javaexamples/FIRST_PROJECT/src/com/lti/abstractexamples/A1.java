package com.lti.abstractexamples;

public class A1 {
public A1(){
	System.out.println("Child class constructor");
	//display();
}
protected void display(){
	System.out.println("method of child");
	
}
}
