package com.lti.abstractexamples;

abstract class Sum {
	public abstract int sumofTwo(int n1,int n2);
    public abstract int sumofThree(int n1,int n2,int n3);
    public void display()
    {
    	System.out.println("Method of class sum");
    }
	

}
