package com.lti.hibernateEx.Relation_OneToOne2_Ex;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEE1")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_E")
	@SequenceGenerator(name="my_entity_seq_gen_E", sequenceName="MY_ENTITY_SEQ_E",allocationSize=1)
	
    @Column(name="EMP_ID")
    private int empId;
    
    @Column(name="EMP_NAME")
    private String empName;

    @OneToOne(mappedBy="employee")
    private Employee_Address employeeAddress;

    public Employee()
    {
        super();
    }

    public Employee(int empId, String empName, Employee_Address employeeAddress)
    {
        super();
        this.empId = empId;
        this.empName = empName;
        this.employeeAddress = employeeAddress;
    }

    public int getEmpId()
    {
        return empId;
    }

    public void setEmpId(int empId)
    {
        this.empId = empId;
    }

    public String getEmpName()
    {
        return empName;
    }

    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public Employee_Address getEmployeeAddress()
    {
        return employeeAddress;
    }

    public void setEmployeeAddress(Employee_Address employeeAddress)
    {
        this.employeeAddress = employeeAddress;
    }

    @Override
    public String toString()
    {
        return "Employee [empId=" + empId + ", empName=" + empName + ", employeeAddress=" + employeeAddress + "]";
    }
}
