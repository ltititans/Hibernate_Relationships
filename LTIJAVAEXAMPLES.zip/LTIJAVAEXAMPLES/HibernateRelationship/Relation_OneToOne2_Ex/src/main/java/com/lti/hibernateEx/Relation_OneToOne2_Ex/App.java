package com.lti.hibernateEx.Relation_OneToOne2_Ex;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);
		
		
		Employee emp = new Employee();
		

		System.out.println("Enter empName");
		String empName = sc.next();
		emp.setEmpName(empName);

		Employee_Address emp_add = new Employee_Address();
		
		System.out.println("Enter street");
		String street = sc.next();
		emp_add.setStreet(street);
		
		System.out.println("Enter city");
		String city = sc.next();
		emp_add.setCity(city);
		
		System.out.println("Enter state");
		String state = sc.next();
		emp_add.setState(state);
		
		
		System.out.println("Enter country");
		String country = sc.next();
		emp_add.setCountry(country);
		
		
		emp.setEmployeeAddress(emp_add);
		emp_add.setEmployee(emp);
		entityManager.persist(emp);
		
	
		entityManager.persist(emp_add);

		System.out.println("Saving Emp_addr to db");
		entityManager.getTransaction().commit();
		System.out.println("Generated author_id = " + emp.getEmpId());
		System.out.println("Generated book_id = " + emp_add.getAddrId());



		sc.close();
		
		
    }
}
