package com.lti.hibernateEx.DeptEmp_OneToMany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEE11")
public class Employee11 {
   private long id;
   private String name;
   private long salary;
   private String address;
   
   private Department1 dept;

   
   
   @Id 
   @Column(name="EMP_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName1")
	@SequenceGenerator(name="somesequenceName1",sequenceName="hi_seq1",allocationSize=1)
public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}


@Column(name="EMP_NAME")
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

@Column(name="EMP_SALARY")
public long getSalary() {
	return salary;
}

public void setSalary(long salary) {
	this.salary = salary;
}

@Column(name="EMP_ADD")
public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}



@ManyToOne
@JoinColumn(name="DEPT_ID")
public Department1 getDept() {
	return dept;
}

public void setDept(Department1 dept) {
	this.dept = dept;
}

public Employee11(long id, String name, long salary, String address, Department1 dept) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.address = address;
	this.dept = dept;
}

public Employee11() {
	super();
}
   
   
   
   
   
}
