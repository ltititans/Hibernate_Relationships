package com.lti.hibernateEx.DeptEmp_OneToMany;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);
		
		
		Department1 dept = new Department1();
		Employee11 emp = new Employee11();
		
		System.out.println("Name:");
		String name = sc.next();
		System.out.println("location");
		String loc=sc.next();
		dept.setDept_name(name);
		dept.setLocation(loc);
		entityManager.persist(dept);
		System.out.println("empl name");
		String empl_name=sc.next();
		System.out.println("salary");
		long sal=sc.nextLong();
		System.out.println("address");
		String add=sc.next();
		emp.setAddress(add);
		emp.setSalary(sal);
		emp.setName(empl_name);
		emp.setDept(dept);
		entityManager.persist(emp);
		entityManager.getTransaction().commit();
		
		
    }
}
