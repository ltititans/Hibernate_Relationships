package com.lti.hibernateEx.DeptEmp_OneToMany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

public class Department1 {
      private long dept_id;
      private String dept_name;
      private String location;
      
      private List<Employee11> emp11;
      
      
      
	public Department1() {
		super();
	}
	public Department1(long dept_id, String dept_name, String location) {
		super();
		this.dept_id = dept_id;
		this.dept_name = dept_name;
		this.location = location;
	}
	
	
	
	
	   @Id 
	   @Column(name="DEPT_ID")
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
		@SequenceGenerator(name="somesequenceName2",sequenceName="hi_seq2",allocationSize=1)
	public long getDept_id() {
		return dept_id;
	}
	public void setDept_id(long dept_id) {
		this.dept_id = dept_id;
	}
	
	
	@Column(name="DEPT_NAME")
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	
	
	@Column(name="DEPT_LOC")
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
	
	@OneToMany(mappedBy="dept", cascade=CascadeType.ALL)
	public List<Employee11> getEmp11() {
		return emp11;
	}
	public void setEmp11(List<Employee11> emp11) {
		this.emp11 = emp11;
	}
	
	
	
      
      
      
      
}
