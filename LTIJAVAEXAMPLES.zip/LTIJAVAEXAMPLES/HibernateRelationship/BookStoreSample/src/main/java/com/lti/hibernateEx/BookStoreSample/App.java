package com.lti.hibernateEx.BookStoreSample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
//OneToOne Example
public class App 
{
	public static void main( String[] args )
	{
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);




		Author author = new Author();

		System.out.println("Enter name");
		String name = sc.next();
		author.setName(name);

		System.out.println("Enter email");
		String email = sc.next();
		author.setEmail(email);





		Book book = new Book();

		System.out.println("Enter title");
		String title = sc.next();
		book.setTitle(title);

		System.out.println("Enter description");
		String description = sc.next();
		book.setDescription(description);

		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Enter date in MM/DD/YYYY format");
		String date = sc.next();
		Date publishedDate;
		try {
			publishedDate = df.parse(date);
			book.setPublishedDate(publishedDate);

		}catch (ParseException e) {

			e.printStackTrace();
		}
		
		
		entityManager.persist(author);

		book.setAuthor(author);


		System.out.println("Saving books to db");
		entityManager.persist(book);

		entityManager.getTransaction().commit();
		System.out.println("Generated author_id = " + author.getAuthor_id());
		System.out.println("Generated book_id = " + book.getBook_id());



		sc.close();
	}
}
