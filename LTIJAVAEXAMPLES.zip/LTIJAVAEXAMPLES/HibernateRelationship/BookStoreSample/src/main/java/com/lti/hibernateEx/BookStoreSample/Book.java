package com.lti.hibernateEx.BookStoreSample;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "BOOK")
public class Book{
    
    private long book_id;
	private String title;
	private String description;
	private Date publishedDate;
	
	private Author author;

	
	
	@Id
	@Column(name = "BOOK_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_B")
	@SequenceGenerator(name="my_entity_seq_gen_B", sequenceName="MY_ENTITY_SEQ_B",allocationSize=1)
	
	
	public long getBook_id() {
		return book_id;
	}

	public void setBook_id(long book_id) {
		this.book_id = book_id;
	}
	
	
	
	
	
	@Column(name = "TITLE")
	public String getTitle() {
		return title;
	}

	

	public void setTitle(String title) {
		this.title = title;
	}

	
	
	
	@Column(name = "DESCRIPTION")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "PUBLISHED_DATE")
    public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "AUTHOR_ID")
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
	
	
	
	
	
	public Book() {
		super();
	}

	public Book(long book_id, String title, String description, Date publishedDate, Author author) {
		super();
		this.book_id = book_id;
		this.title = title;
		this.description = description;
		this.publishedDate = publishedDate;
		this.author = author;
	}

	

	
}
