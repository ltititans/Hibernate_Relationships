package com.lti.hibernateEx.BookStoreSample;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "AUTHOR")
public class Author{
	private long author_id;
	private String name;
	private String email;





	@Id
	@Column(name = "AUTHOR_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_A")
	@SequenceGenerator(name="my_entity_seq_gen_A", sequenceName="MY_ENTITY_SEQ_A",allocationSize=1)


	public long getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(long author_id) {
		this.author_id = author_id;
	}



	@Column(name = "NAME")
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}




	@Column(name = "EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	public Author() {
		super();
	}

	public Author(long author_id, String name, String email) {
		super();
		this.author_id = author_id;
		this.name = name;
		this.email = email;
	}



}
