package com.lti.hibernateEx.Relationship_Ex;


import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



///one-to-one bidirectional

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);




		Student stud = new Student();
		
		

		System.out.println("Enter firstName");
		String firstName = sc.next();
		stud.setFirstName(firstName);

		System.out.println("Enter lastName");
		String lastName = sc.next();
		stud.setLastName(lastName);


		System.out.println("Enter section");
		String section = sc.next();
		stud.setSection(section);



		Address address = new Address();

		System.out.println("Enter street");
		String street = sc.next();
		address.setStreet(street);

		System.out.println("Enter city");
		String city = sc.next();
		address.setCity(city);

		
		System.out.println("Enter country");
		String country = sc.next();
		address.setCountry(country);

		
		
		stud.setAddress(address);
		address.setStudent(stud);
		entityManager.persist(stud);

	//	stud = entityManager.find(Student.class, stud.getStudent_id());

		System.out.println("Saving books to db");
		entityManager.persist(address);

		entityManager.getTransaction().commit();
		System.out.println("Generated author_id = " + stud.getStudent_id());
		System.out.println("Generated book_id = " + address.getA_id());



		sc.close();
    }
}
