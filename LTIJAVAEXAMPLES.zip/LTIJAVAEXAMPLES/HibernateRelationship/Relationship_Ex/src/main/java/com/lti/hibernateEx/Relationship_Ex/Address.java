package com.lti.hibernateEx.Relationship_Ex;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
@Entity
@Table(name = "ADDRESS")
public class Address {
 

   
  
   
   
   
@Id
@Column(name = "ID")
@GenericGenerator(name="gen", strategy="foreign",parameters=@Parameter(name="property", value="student"))
@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "gen")
@SequenceGenerator(name="gen", sequenceName="MY_ENTITY_SEQ_AD",allocationSize=1)
private long a_id;


@Column(name = "STREET")
private String street;

@Column(name = "CITY")
private String city;


@Column(name = "COUNTRY")
private String country;





public long getA_id() {
	return a_id;
}
public void setA_id(long a_id) {
	this.a_id = a_id;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}






@OneToOne
@PrimaryKeyJoinColumn

private Student student;

public Student getStudent() {
	return student;
}
public void setStudent(Student student) {
	this.student = student;
}












public Address() {
	super();
}
public Address(String street, String city, String country, Student student) {
	super();
	this.street = street;
	this.city = city;
	this.country = country;
	this.student = student;
}


   
   
   
}
