package com.lti.hibernateEx.Relation_OneToMany1_EX;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "category1")
public class Category1 {
	private long id;
	private String name;
	private Set<Product> products;
	public Category1(){}
	public Category1(String name) {
		super();
		this.name = name;
	}
	@Id
	@Column(name="CATEGORY_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName")
	@SequenceGenerator(name="somesequenceName",sequenceName="hi_seqs",allocationSize=1)

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name="CATEGORY_NAME")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	

	@OneToMany(mappedBy="category", cascade=CascadeType.ALL)
	public Set<Product> getProducts() {
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}
}
