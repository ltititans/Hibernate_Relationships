package com.lti.hibernateEx.Relation_OneToMany1_EX;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        	Category1 cat=new Category1("Computer");
        	
        	Product pc=new Product(" DELL PC", "Quad-Co", 1200, cat);
        	
        	Product laptop=new Product("MacBook","Apple ", 2100, cat);
        	
        	Product phone = new Product("iPhone 5", "Apple", 499, cat);
        
        	Product tablet=new Product("iPad 3", "Apple", 1099, cat);
        	
        	
        	
        	//Category1 ct= new Category1();
        	Set <Product> ps=new HashSet<Product>();
        	ps.add(pc);
        	ps.add(laptop);
        	ps.add(phone);
        	ps.add(tablet);
        	
        	
        	
        	
        	cat.setProducts(ps);
        	
        	
        	
        	em.persist(cat);
        	
        	
        	
        	em.persist(pc);
        	em.persist(tablet);
        	em.persist(phone);
        	em.persist(laptop);
        	
        	 
        	em.getTransaction().commit();
        	
        	em.close();  
            emf.close();  
    }
}
