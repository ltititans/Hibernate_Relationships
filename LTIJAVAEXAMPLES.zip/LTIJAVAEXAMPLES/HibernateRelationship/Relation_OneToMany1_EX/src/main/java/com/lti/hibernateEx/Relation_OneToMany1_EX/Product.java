package com.lti.hibernateEx.Relation_OneToMany1_EX;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="product1")

public class Product {
	@Id
	private long id;
	private String name;
	private String description;
	private float price;
	
	private Category1 category;

	public Product() {
		
	}

	

	public Product(long id, String name, String description, float price, Category1 category) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.category = category;
	}

	


	public Product(String name, String description, float price, Category1 category) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
		this.category = category;
	}

	@Id
	@Column(name="PRODUCT_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName")
	@SequenceGenerator(name="somesequenceName",sequenceName="hi_seqp",allocationSize=1)


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	@Column(name="PRODUCT_NAME")

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Column(name="PRODUCT_DESC")

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	@Column(name="PRODUCT_PRICE")

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@ManyToOne
	@JoinColumn(name="CATEGORY_ID")
	
	public Category1 getCategory() {
		return category;
	}

	public void setCategory(Category1 category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", category=" + category + "]";
	}
	
	
	
	
	
	
}
