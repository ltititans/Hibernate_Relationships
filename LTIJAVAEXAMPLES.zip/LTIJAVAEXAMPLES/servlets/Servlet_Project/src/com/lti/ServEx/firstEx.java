package com.lti.ServEx;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class firstEx
 */
public class firstEx extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public firstEx() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("<h1>Hi welcome</h1>");
		out.print("<form>");

		  out.print("<h1>Register</h1>");
		   out.print("<p>Please fill in this form to create an account.</p>");
		   out.print("<hr>");

		    out.print("<label for='email'><b>Email</b></label>");
		   out.print(" <input type='text' placeholder='Enter Email' name='email' required>");
		  out.print("<label for='psw'><b>Password</b></label>");
		   out.print("<input type='password' placeholder='Enter Password' name='psw' required>");
		    out.print("<label for='psw-repeat'><b>Repeat Password</b></label>");
		   out.print("<input type='password' placeholder='Repeat Password' name='psw-repeat' required>");
		    out.print("<hr>");
		    out.print("<p>By creating an account you agree to our <a href='#'>Terms & Privacy</a>.</p>");

		    out.print("<button type='submit' class='registerbtn'>Register</button>");
		  
		  
		  out.print("<div class='container signin'>");
		   out.print("<p>Already have an account? <a href='#'>Sign in</a>.</p>");
		out.print("</form>");

		out.print("</body>");
		out.print("</html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
