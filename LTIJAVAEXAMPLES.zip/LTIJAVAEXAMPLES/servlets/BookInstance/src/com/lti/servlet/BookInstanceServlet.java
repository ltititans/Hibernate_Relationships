package com.lti.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.DAO.BookInstanceDao;
import com.lti.books.BookInstance;

@WebServlet("/")
public class BookInstanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookInstanceDao bookInstanceDAO;
	
	public void init() {
		bookInstanceDAO= new BookInstanceDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertBookInstance(request, response);
				break;
			case "/delete":
				deleteBookInstance(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateBookInstance(request, response);
				break;
			default:
				listBookInstance(request, response);
				
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listBookInstance(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<BookInstance> listBookInstance = bookInstanceDAO.selectAllBookInstance();
		request.setAttribute("listBookInstance", listBookInstance);
		RequestDispatcher dispatcher = request.getRequestDispatcher("book-instance-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("book-instance-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("copy_instance"));
		BookInstance existingBK = bookInstanceDAO.selectBookInstance(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("book-instance-form.jsp");
		request.setAttribute("bookInstance", existingBK);
		dispatcher.forward(request, response);

	}

	private void insertBookInstance(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
    int store_id = Integer.parseInt(request.getParameter("store_id"));
		int order_details_id = Integer.parseInt(request.getParameter("order_details_id"));
		int isbn = Integer.parseInt(request.getParameter("isbn"));
		BookInstance newBK = new BookInstance(store_id, isbn, order_details_id);
		bookInstanceDAO.insertBookInstance(newBK);
		response.sendRedirect("list");
	}

	private void updateBookInstance(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int isbn = Integer.parseInt(request.getParameter("isbn"));
    int order_details_id = Integer.parseInt(request.getParameter("order_details_id"));
		int copy_instance =Integer.parseInt( request.getParameter("copy_instance"));
		int store_id =Integer.parseInt( request.getParameter("store_id"));

		BookInstance bk = new BookInstance(copy_instance, store_id, isbn, order_details_id);
		bookInstanceDAO.updateBookInstance(bk);
		response.sendRedirect("list");
	}

	private void deleteBookInstance(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int copy_instance = Integer.parseInt(request.getParameter("copy_instance"));
		bookInstanceDAO.deleteBookInstance(copy_instance);
		response.sendRedirect("list");

	}
}