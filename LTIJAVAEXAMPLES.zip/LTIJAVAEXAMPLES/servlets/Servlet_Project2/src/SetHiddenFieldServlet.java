

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetHiddenFieldServlet
 */
@WebServlet("/SetHiddenFieldServlet")
public class SetHiddenFieldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("userName").trim();
		String password=request.getParameter("password").trim();
		if(userName==null || userName.equals(" ")||
			  password==null||password.equals("")){
			out.print("Please enter both username "+ "and password.<br/><br/>");
			RequestDispatcher requestDispatcher =request.getRequestDispatcher("login.html");
			requestDispatcher.include(request,response);
		}
		else if(userName.equals("jai") && password.equals("1234")){
			out.println("Logged in successfully.<br/>");
			out.println("Click on the below button to see "+ "the values of Username and password.<br/>");
			out.println("<form action= 'GetHiddenFieldServlet'" + "method='POST'>");
			out.print("<input type='hidden' name='userName' "+ "value="+userName + "'>");
			out.print("<input type='hidden' name='password' "+ "value="+password + "'>");
			out.print("<input type='submit' value='See Values'>");
			out.print("</form>");
			out.close();
		}
		else
		{
			out.print("Wrong username or password. <br/><br/>");
			RequestDispatcher rd= request.getRequestDispatcher("login.html");
			rd.include(request, response);
			
		}
		
		
	}

}
