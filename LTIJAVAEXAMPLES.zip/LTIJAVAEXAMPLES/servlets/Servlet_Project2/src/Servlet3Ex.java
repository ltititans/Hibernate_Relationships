

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet3Ex
 */
@WebServlet("/Servlet3Ex")
public class Servlet3Ex extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String userName = null;

    /**
     * Default constructor. 
     */
    public Servlet3Ex() {
        // TODO Auto-generated constructor stub
    }
    public void service(HttpServletRequest req, HttpServletResponse resp) throws IOException{
    	resp.setContentType("text/plain");
    	PrintWriter out = resp.getWriter();
    	userName = req.getRemoteUser();
    	sayHello(out);
    	out.close();
    }

	private void sayHello(PrintWriter out) {
		// TODO Auto-generated method stub
		out.println("Hello there "+userName);
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
