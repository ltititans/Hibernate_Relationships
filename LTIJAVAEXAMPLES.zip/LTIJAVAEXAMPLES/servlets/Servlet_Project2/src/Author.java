

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class books
 */
@WebServlet("/Author")
public class Author extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Author() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	       
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Statement st=null;
		Connection con=null;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer aid = Integer.parseInt(request.getParameter("Author_ID"));
		String fname = request.getParameter("First_Name");
		String lname = request.getParameter("Last_Name");
		String email = request.getParameter("Email_ID");
		try{
		 Class.forName("oracle.jdbc.driver.OracleDriver");	 
		 
		 con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123");
			PreparedStatement ps = con.prepareStatement("insert into author values(?,?,?,?)");
		
			con.setAutoCommit(false);
			ps.setInt(1,aid );
			ps.setString(2, fname);
			ps.setString(3, lname);
			ps.setString(4, email);

			int i = ps.executeUpdate();
			System.out.println(i+ "records affected " );
			con.close();

			con.commit();	
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
	}

	
} 