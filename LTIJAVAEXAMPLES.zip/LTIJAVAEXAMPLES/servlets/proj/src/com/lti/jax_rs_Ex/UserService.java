package com.lti.jax_rs_Ex;


import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/UserService")
public class UserService {

	UserDao userDao=new UserDao();
	@GET
	@Path("/users")
	@Produces(MediaType.APPLICATION_XML)
	public List<User> getUsers() throws SQLException
	{
		return userDao.getAllUsers();
	}
	
}
