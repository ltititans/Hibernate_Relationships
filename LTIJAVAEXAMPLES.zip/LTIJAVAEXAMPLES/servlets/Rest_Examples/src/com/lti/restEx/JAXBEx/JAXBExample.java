package com.lti.restEx.JAXBEx;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class JAXBExample {
private static final String FILE_NAME="jaxb_emp.xml";
public static void main(String[] args) throws JAXBException{
	Emp emp=new Emp();
	emp.setId(1);
	emp.setAge(25);
	emp.setName("shan");
	emp.setGender("Male");
	emp.setRole("Trainer");
	emp.setPassword("sensitive");
	//marshalling
	jaxbObjectToXML(emp);
	//unmarshalling
	Emp empFromFile=jabXMLToObject();
	System.out.println(empFromFile.toString());
	
	
	
}
private static Emp jabXMLToObject() throws JAXBException {
	// TODO Auto-generated method stub
	JAXBContext context=JAXBContext.newInstance(Emp.class);
	Unmarshaller un=context.createUnmarshaller();
	Emp emp=(Emp) un.unmarshal(new File(FILE_NAME));
	return emp;
}
private static void jaxbObjectToXML(Emp emp) throws JAXBException {
	JAXBContext context=JAXBContext.newInstance(Emp.class);
	Marshaller m=context.createMarshaller();
	m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
	m.marshal(emp, new File(FILE_NAME));
	
	
	
	
}
}
