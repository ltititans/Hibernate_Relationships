package com.jspex.BeanClasses;

public class languageBean {
	private String name;
	private String language;
	public languageBean(){}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLanguageComments(){
		if(language.equals("Java")){
			return "The king of OO languages.";
			
		}
		else if(language.equals("Perl")){
			return "ok if you have incomprehensible code.";
		}
		else{
			return "Sorry i have never heard of"+language+ ".";
		}
	}

}
