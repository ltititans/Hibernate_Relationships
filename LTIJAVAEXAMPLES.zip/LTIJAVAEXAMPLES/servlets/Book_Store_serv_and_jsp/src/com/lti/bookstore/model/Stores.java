package com.lti.bookstore.model;

public class Stores {

	private int store_id;
	private String Address;
	private String city;
	private String state;
	private String zipcode;
	@Override
	public String toString() {
		return "Stores [store_id=" + store_id + ", Address=" + Address + ", city=" + city + ", state=" + state
				+ ", zipcode=" + zipcode + "]";
	}
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public Stores(int store_id, String address, String city, String state, String zipcode) {
		super();
		this.store_id = store_id;
		Address = address;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}
	
}
