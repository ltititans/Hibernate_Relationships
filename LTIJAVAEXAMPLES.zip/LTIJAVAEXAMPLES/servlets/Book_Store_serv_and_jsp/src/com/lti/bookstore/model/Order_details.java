package com.lti.bookstore.model;



	public class Order_details {
	    private int order_detail_id;
	    private double price;
	    private double discount;
	    private Orders o;
		public Order_details(int order_detail_id, double price, double discount, Orders o) {
			super();
			this.order_detail_id = order_detail_id;
			this.price = price;
			this.discount = discount;
			this.o = o;
		}
		public int getOrder_detail_id() {
			return order_detail_id;
		}
		public void setOrder_detail_id(int order_detail_id) {
			this.order_detail_id = order_detail_id;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public double getDiscount() {
			return discount;
		}
		public void setDiscount(double discount) {
			this.discount = discount;
		}
		public Orders getO() {
			return o;
		}
		public void setO(Orders o) {
			this.o = o;
		}
		@Override
		public String toString() {
			return "Order_details [order_detail_id=" + order_detail_id + ", price=" + price + ", discount=" + discount
					+ ", o=" + o + "]";
		} 
	    
	}
