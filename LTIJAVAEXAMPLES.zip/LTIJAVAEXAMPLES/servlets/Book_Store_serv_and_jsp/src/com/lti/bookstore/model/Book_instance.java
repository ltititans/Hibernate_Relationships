package com.lti.bookstore.model;



public class Book_instance {
 private int copy_instance;
 private Books b;
 private Order_details Od;
 private Stores s;
public Book_instance(int copy_instance, Books b, Order_details od, Stores s) {
	super();
	this.copy_instance = copy_instance;
	this.b = b;
	Od = od;
	this.s = s;
}
public int getCopy_instance() {
	return copy_instance;
}
public void setCopy_instance(int copy_instance) {
	this.copy_instance = copy_instance;
}
public Books getB() {
	return b;
}
public void setB(Books b) {
	this.b = b;
}
public Order_details getOd() {
	return Od;
}
public void setOd(Order_details od) {
	Od = od;
}
public Stores getS() {
	return s;
}
public void setS(Stores s) {
	this.s = s;
}
@Override
public String toString() {
	return "Book_instance [copy_instance=" + copy_instance + ", b=" + b + ", Od=" + Od + ", s=" + s + "]";
}


}
