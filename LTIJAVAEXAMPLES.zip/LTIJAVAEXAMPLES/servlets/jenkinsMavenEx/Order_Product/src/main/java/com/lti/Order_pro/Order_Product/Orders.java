package com.lti.Order_pro.Order_Product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ORDERS")
public class Orders {
	private long order_id;
	private Date order_date;
	
	private Product product;

	public Orders() {
		super();
	}

	public Orders(long order_id, Date order_date, Product product) {
		super();
		this.order_id = order_id;
		this.order_date = order_date;
		this.product = product;
	}

	
	
	
	@Id
	@Column(name = "ORDER_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_O")
	@SequenceGenerator(name="my_entity_seq_gen_O", sequenceName="MY_ENTITY_SEQ_O",allocationSize=1)
	public long getOrder_id() {
		return order_id;
	}

	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}

	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ORDER_DATE")
	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	
	
	

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
    
	
	
	
	

}





