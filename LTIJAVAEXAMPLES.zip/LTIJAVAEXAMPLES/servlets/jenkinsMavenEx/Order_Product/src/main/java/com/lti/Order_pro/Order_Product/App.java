

package com.lti.Order_pro.Order_Product;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;






public class App
{
    public static void main( String[] args )
    {
    	EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("productersistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		entityManager.getTransaction().begin();

		Scanner sc = new Scanner(System.in);




		Product product = new Product();

		System.out.println("Enter productroduct name");
		String name = sc.next();
		product.setName(name);

		System.out.println("Enter productrice");
		Long productrice = sc.nextLong();
		product.setPrice(productrice);





		Orders ord = new Orders();

		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Enter date in MM/DD/YYYY format");
		String date = sc.next();
		Date order_date;
		try {
			order_date = df.parse(date);
			ord.setOrder_date(order_date);

		}catch (ParseException e) {

			e.printStackTrace();
		}
		entityManager.persist(product);

		ord.setProduct(product);


		System.out.println("Saving orders to db");
		entityManager.persist(ord);

		entityManager.getTransaction().commit();
		System.out.println("Generated author_id = " + product.getP_id());
		System.out.println("Generated book_id = " + ord.getOrder_id());



		sc.close();
    }
}
