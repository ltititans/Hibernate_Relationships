package com.lti.Order_pro.Order_Product;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

public class Product {
	private long p_id;
	private String name;
	private long price;


	@Id
	@Column(name = "P_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_P")
	@SequenceGenerator(name="my_entity_seq_gen_P", sequenceName="MY_ENTITY_SEQ_P",allocationSize=1)


	public long getP_id() {
		return p_id;
	}
	public void setP_id(long p_id) {
		this.p_id = p_id;
	}



	@Column(name = "NAME")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	@Column(name = "PRICE")
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	
	
	
	
	public Product(long p_id, String name, long price) {
		super();
		this.p_id = p_id;
		this.name = name;
		this.price = price;
	}
	public Product() {
		super();
	}






}
