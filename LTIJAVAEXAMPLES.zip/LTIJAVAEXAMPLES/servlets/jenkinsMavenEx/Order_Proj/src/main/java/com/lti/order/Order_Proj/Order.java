package com.lti.order.Order_Proj;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Orders")

public class Order {
  private int orderId;
  private String orderName;
  @Temporal(TemporalType.DATE)

	private Date date;
  
  
  @Id
  @Column(name = "orderId")
  @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen")
  @SequenceGenerator(name="my_entity_seq_gen", sequenceName="MY_ENTITY_SEQ3",allocationSize=2)
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}


@Column(name="orderName")
public String getOrderName() {
	return orderName;
}
public void setOrderName(String orderName) {
	this.orderName = orderName;
}




@Column(name="date1")
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
  
  
  
}
