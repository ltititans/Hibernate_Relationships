package com.lti.order.Order_Proj;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="OrderDetails")
public class OrderDetails extends  {
	
	
	private int orderDetailsId;
	private int price;
	
	


	
	

	 @Id
	  @Column(name = "orderDetailsId")
	  @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen1")
	  @SequenceGenerator(name="m y_entity_seq_gen1", sequenceName="MY_ENTITY_SEQ4",allocationSize=2)

	public int getOrderDetailsId() {
		return orderDetailsId;
	}


	public void setOrderDetailsId(int orderDetailsId) {
		this.orderDetailsId = orderDetailsId;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public Order getOrd() {
		return ord;
	}


	public void setOrd(Order ord) {
		this.ord = ord;
	}
	
	
	

	
	
	  
	  
	 
	
}
