package com.lti.order.Order_Proj;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OrderDelete {
      public static void deleteOrder(){
    	  EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("persistence");
  		EntityManager entityManager = entityManagerFactory.createEntityManager();
  		System.out.println("Starting Transaction");
  		entityManager.getTransaction().begin();




  		Scanner sc = new Scanner(System.in);   

  		//Order order = new Order();

  		System.out.println("Enter the id");
  		int id = sc.nextInt();

        
  	//System.out.println("Generated Order ID ="  + order.getOrderId());
  		Order ord=entityManager.find(Order.class, id);

  		System.out.println("Saving Order to Database");

  		entityManager.remove(ord);
  		entityManager.getTransaction().commit();
  		
  		
  		
  		
  		
  		@SuppressWarnings("unchecked")
		List<Order> listOrder = entityManager.createQuery(" Select o FROM Order o").getResultList();
		if(listOrder == null)
		{
			System.out.println("No order found ");
		}
		else
		{
			for(Order ord1: listOrder){
				System.out.println("Order name=" + ord1.getOrderName() + ", Order id " + ord1.getOrderId());
			}
		}
      }
}
