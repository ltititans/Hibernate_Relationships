package com.lti.order.Order_Proj;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting Transaction");
		entityManager.getTransaction().begin();

		
		
		
		
		
		OrderDetails orderD = new OrderDetails();
		
		
  	Scanner sc = new Scanner(System.in);
    	int n;
    	System.out.println("Enter n");
    	n = sc.nextInt();
    	switch(n){
    	case 1: OrderCreate.createOrder();
    	        
   	        break;
    	
    	case 2:OrderUpdate.updateOrder();
    	        break;
    	
    	case 3:OrderDisplay.DisplayOrder();
    	       break;
    	
    	case 4:OrderDelete.deleteOrder();
    	       break;
    	        
    	}
    	
       
      
    	
    	
    	
    	

       
		entityManager.close();
		entityManagerFactory.close();
    }

	

	
}
