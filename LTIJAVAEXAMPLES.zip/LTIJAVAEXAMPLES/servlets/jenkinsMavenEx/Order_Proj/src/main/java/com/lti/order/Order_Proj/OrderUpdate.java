package com.lti.order.Order_Proj;

import java.util.Date;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OrderUpdate {
	public static void updateOrder(){
		EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting Transaction");
		entityManager.getTransaction().begin();



		Date date = new Date();

		Scanner sc = new Scanner(System.in);   

		Order order = new Order();

		System.out.println("Enter the id");
		int id = sc.nextInt();
		order.setOrderId(id);

		System.out.println("Enetr phone number");
		String phone = sc.next();
		order.setOrderName(phone);


		order.setDate(date);
		System.out.println("Saving Order to Database");

		entityManager.merge(order);
		entityManager.getTransaction().commit();
		System.out.println("Generated Order ID ="  + order.getOrderId());
		Order ord=entityManager.find(Order.class, order.getOrderId());
		System.out.println("got object " + ord.getOrderName() + " "+ord.getOrderId());
	}
}
