package com.lti.mapping.MultipleTable;

public class Products extends BaseEntity{
   
        private String PName;
        
}
