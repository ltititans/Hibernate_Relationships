package com.lti.mapping.MultipleTable;

public class Orders extends BaseEntity {
private String ordName;
private Products product;
}
