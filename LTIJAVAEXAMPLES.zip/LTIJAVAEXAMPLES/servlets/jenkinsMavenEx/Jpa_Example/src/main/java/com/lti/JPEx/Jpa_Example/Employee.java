package com.lti.JPEx.Jpa_Example;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="employee")


public class Employee {

	    private int employeeId;
	    private String empname;
	    private String branch;
	    
	    @Id
	    @Column(name ="employeeId")
	    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen")
	    @SequenceGenerator(name="my_entity_seq_gen", sequenceName="MY_ENTITY_SEQ",allocationSize=1)
	    public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
	    
	    
		public Employee(int employeeId, String name, String branch) {
			super();
			this.employeeId = employeeId;
			this.empname = name;
			this.branch = branch;
		}
		
		public Employee() {
			// TODO Auto-generated constructor stub
		}
		@Column(name="empname")
		public String getName() {
			return empname;
		}
		public void setName(String name) {
			this.empname = name;
		}
		@Column(name="branch")
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
	    
	    
		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", name=" + empname + ", branch=" + branch + "]";
		}
	   
	
}
